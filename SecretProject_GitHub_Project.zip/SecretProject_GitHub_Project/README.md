# Secret Project — Phase 01–50 GitHub/Android Build Project

This is a GitHub-ready Unity Android project assembled from the Phase 01–50 source packages.

## Unity
- Recommended editor: Unity 2022.3 LTS
- Target: Android
- Product: Secret Project
- Package identifier: com.secretproject.mmo

## Important
The MMO backend (PostgreSQL, Redis, API, WebSocket/shard services) runs on a server/cloud host, not on the Android phone.

The included GitHub Actions workflow builds an Android APK with GameCI. A Unity license/account must be configured in GitHub Actions secrets according to the selected Unity licensing method.

## GitHub
Upload the contents of this folder to a GitHub repository (not the outer ZIP itself if you want Actions to run immediately).
Then open **Actions → Build Android APK → Run workflow**.

The resulting APK is published as a workflow artifact named `SecretProject-Android-APK`.

## Source
`SourcePackages/SecretProject_Phase01_50_Complete_Combined.zip` contains the original combined phase packages.

## Server endpoint
Set the production API/WebSocket endpoint in the project's runtime configuration before deployment. Do not hard-code database or Redis credentials into the APK.
