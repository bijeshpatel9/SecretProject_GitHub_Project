using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.Networking
{
    public class ServerRewardAuthority : MonoBehaviour
    {
        readonly HashSet<string> defeatedBosses = new HashSet<string>();

        public bool GrantBossReward(string playerId, string bossId, string skillId)
        {
            if (string.IsNullOrEmpty(playerId) ||
                string.IsNullOrEmpty(bossId) ||
                string.IsNullOrEmpty(skillId))
                return false;

            string key = playerId + ":" + bossId;

            // Prototype: prevents duplicate rewards during this server session.
            if (!defeatedBosses.Add(key))
                return false;

            Debug.Log($"SERVER REWARD: {playerId} defeated {bossId}, unlock {skillId}");
            return true;
        }
    }
}