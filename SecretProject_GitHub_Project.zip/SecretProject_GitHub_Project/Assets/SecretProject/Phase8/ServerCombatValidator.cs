using UnityEngine;

namespace SecretProject.Networking
{
    public class ServerCombatValidator : MonoBehaviour
    {
        public bool ValidateAttack(string playerId, float damage, float cooldown)
        {
            if (string.IsNullOrEmpty(playerId)) return false;
            if (!ServerAuthorityRules.ValidateDamage(damage)) return false;
            if (!ServerAuthorityRules.ValidateCooldown(cooldown)) return false;

            // Production server should additionally validate:
            // position, attack timing, target, line-of-sight and anti-cheat rules.
            return true;
        }

        public bool ValidateSkillUse(NetworkPlayerState player, string skillId)
        {
            return ServerAuthorityRules.ValidateSkillOwnership(player, skillId);
        }
    }
}