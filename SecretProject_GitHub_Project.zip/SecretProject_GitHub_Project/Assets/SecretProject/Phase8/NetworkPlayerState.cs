using System;
using UnityEngine;

namespace SecretProject.Networking
{
    [Serializable]
    public class NetworkPlayerState
    {
        public string playerId;
        public int level;
        public long experience;
        public int gold;
        public string[] unlockedSkills = Array.Empty<string>();
    }
}