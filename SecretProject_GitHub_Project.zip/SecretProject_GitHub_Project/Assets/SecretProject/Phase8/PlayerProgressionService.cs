using System;
using UnityEngine;

namespace SecretProject.Networking
{
    public class PlayerProgressionService : MonoBehaviour
    {
        public NetworkPlayerState State { get; private set; }

        public void Initialize(string playerId)
        {
            State = new NetworkPlayerState
            {
                playerId = playerId,
                level = 1,
                experience = 0,
                gold = 0
            };
        }

        public void AddExperience(long amount)
        {
            if (State == null || amount <= 0) return;
            State.experience += amount;

            while (State.experience >= RequiredXP(State.level))
            {
                State.experience -= RequiredXP(State.level);
                State.level++;
            }
        }

        public void AddGold(int amount)
        {
            if (State == null) return;
            State.gold = Math.Max(0, State.gold + amount);
        }

        public void UnlockSkill(string skillId)
        {
            if (State == null || string.IsNullOrEmpty(skillId)) return;
            foreach (var id in State.unlockedSkills)
                if (id == skillId) return;

            var list = new System.Collections.Generic.List<string>(State.unlockedSkills);
            list.Add(skillId);
            State.unlockedSkills = list.ToArray();
        }

        long RequiredXP(int level)
        {
            return Math.Max(100, level * 100L);
        }
    }
}