using UnityEngine;

namespace SecretProject.Networking
{
    public static class ServerAuthorityRules
    {
        public static bool ValidateDamage(float damage)
        {
            return damage >= 0f && damage <= 1000000f;
        }

        public static bool ValidateCooldown(float cooldown)
        {
            return cooldown >= 0f && cooldown <= 3600f;
        }

        public static bool ValidateSkillOwnership(NetworkPlayerState player, string skillId)
        {
            if (player == null || string.IsNullOrEmpty(skillId)) return false;
            foreach (string id in player.unlockedSkills)
                if (id == skillId) return true;
            return false;
        }
    }
}