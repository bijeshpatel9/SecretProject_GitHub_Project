using UnityEngine;

namespace SecretProject.Networking
{
    public class Phase8Bootstrap : MonoBehaviour
    {
        public PlayerProgressionService progression;
        public ServerCombatValidator combatValidator;
        public ServerRewardAuthority rewardAuthority;

        void Awake()
        {
            if (progression == null) progression = GetComponent<PlayerProgressionService>();
            if (combatValidator == null) combatValidator = GetComponent<ServerCombatValidator>();
            if (rewardAuthority == null) rewardAuthority = GetComponent<ServerRewardAuthority>();
        }

        void Start()
        {
            if (progression != null && progression.State == null)
                progression.Initialize("LOCAL_PROTOTYPE_PLAYER");
        }
    }
}