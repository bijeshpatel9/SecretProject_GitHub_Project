using UnityEngine;

namespace SecretProject.Networking
{
    public class NetworkCombatBridge : MonoBehaviour
    {
        public ServerCombatValidator validator;

        public bool RequestAttack(string playerId, float damage, float cooldown)
        {
            if (validator == null) validator = GetComponent<ServerCombatValidator>();
            return validator != null &&
                   validator.ValidateAttack(playerId, damage, cooldown);
        }

        public bool RequestSkill(NetworkPlayerState player, string skillId)
        {
            if (validator == null) validator = GetComponent<ServerCombatValidator>();
            return validator != null &&
                   validator.ValidateSkillUse(player, skillId);
        }
    }
}