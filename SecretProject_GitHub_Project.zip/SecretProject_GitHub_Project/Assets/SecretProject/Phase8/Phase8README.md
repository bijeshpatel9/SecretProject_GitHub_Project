# Secret Project — Phase 8: MMO Networking Foundation

## Goal
Move important MMO decisions toward server authority.

## Included
- NetworkPlayerState
- Server-side combat validation hooks
- Skill ownership validation
- Player level/XP/gold progression service
- One-time boss reward authority prototype
- Network combat bridge
- Bootstrap

## Important
These scripts are an architecture/prototype layer, NOT a real production MMO server.

For production:
1. Use a real authoritative game server.
2. Store player/boss/skill state in a persistent database.
3. Never trust client damage, cooldown, position or reward claims.
4. Add authentication/session validation.
5. Add server tick, lag compensation and reconciliation.
6. Add anti-cheat/rate limiting.
7. Validate the 15 special boss defeats and SS+ skill ownership on the server.

## Unity setup
Create a server/network manager GameObject and add:
- ServerCombatValidator
- PlayerProgressionService
- ServerRewardAuthority
- NetworkCombatBridge
- Phase8Bootstrap

## Phase 8 flow
Client Input
 -> Network Request
 -> Server Validation
 -> Server Simulation/Decision
 -> Persistent State
 -> Replicated Result

## Next
Phase 9 can build the persistent MMO backend layer:
authentication/session model, database repositories, boss-defeat persistence,
SS+ ownership persistence, inventory/player save model and secure APIs.
