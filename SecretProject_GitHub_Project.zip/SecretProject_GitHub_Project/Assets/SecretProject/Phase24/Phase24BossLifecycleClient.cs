using System;
using UnityEngine;

namespace SecretProject.Phase24;

[Serializable]
public sealed class BossLifecycleClientSnapshot
{
    public string InstanceId;
    public string WorldId;
    public string ShardId;
    public string ZoneId;
    public string BossId;
    public float Health;
    public float MaxHealth;
    public int Phase;
    public bool Active;
    public bool Defeated;
    public long Version;
    public long ServerTick;
}

public sealed class Phase24BossLifecycleClient : MonoBehaviour
{
    public BossLifecycleClientSnapshot Current { get; private set; }

    public void ApplyServerSnapshot(BossLifecycleClientSnapshot snapshot)
    {
        if (snapshot == null) return;
        if (Current != null &&
            snapshot.InstanceId == Current.InstanceId &&
            snapshot.Version < Current.Version)
            return;

        Current = snapshot;
        // Presentation only. Never send modified boss state back to server.
    }
}
