using UnityEngine;

namespace SecretProject.Phase24;

public sealed class Phase24Bootstrap : MonoBehaviour
{
    [SerializeField] private Phase24BossLifecycleClient bossClient;

    private void Awake()
    {
        if (bossClient == null)
            bossClient = GetComponent<Phase24BossLifecycleClient>();

        if (bossClient == null)
            bossClient = gameObject.AddComponent<Phase24BossLifecycleClient>();
    }
}
