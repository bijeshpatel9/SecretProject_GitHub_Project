using System;
using System.Collections;
using System.Text;
using UnityEngine;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Tasks;

namespace SecretProject.Phase14
{
    public class RealtimeWebSocketClient : MonoBehaviour
    {
        [SerializeField] private string websocketUrl = "ws://localhost:5000/ws";
        [SerializeField] private float heartbeatInterval = 5f;

        public bool IsConnected => socket != null && socket.State == WebSocketState.Open;
        public event Action<string> MessageReceived;
        public event Action Connected;
        public event Action<string> Disconnected;

        private ClientWebSocket socket;
        private CancellationTokenSource cts;
        private float heartbeatTimer;

        public void SetUrl(string url) => websocketUrl = url;

        public async void Connect(string playerId, string sessionToken)
        {
            if (IsConnected) return;

            try
            {
                socket = new ClientWebSocket();
                cts = new CancellationTokenSource();
                await socket.ConnectAsync(new Uri(websocketUrl), cts.Token);

                Connected?.Invoke();
                await SendJson(new RealtimeEnvelope {
                    type = "hello",
                    payload = JsonUtility.ToJson(new HelloPayload {
                        playerId = playerId,
                        sessionToken = sessionToken,
                        clientTimeMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                    })
                });

                _ = ReceiveLoop(cts.Token);
            }
            catch (Exception e)
            {
                Disconnected?.Invoke(e.Message);
            }
        }

        void Update()
        {
            if (!IsConnected) return;

            heartbeatTimer += Time.deltaTime;
            if (heartbeatTimer >= heartbeatInterval)
            {
                heartbeatTimer = 0f;
                _ = SendJson(new RealtimeEnvelope {
                    type = "heartbeat",
                    payload = JsonUtility.ToJson(new HeartbeatPayload {
                        clientTimeMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                    })
                });
            }
        }

        public async Task SendJson(RealtimeEnvelope envelope)
        {
            if (!IsConnected) return;

            byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(envelope));
            await socket.SendAsync(
                new ArraySegment<byte>(bytes),
                WebSocketMessageType.Text,
                true,
                cts.Token);
        }

        private async Task ReceiveLoop(CancellationToken token)
        {
            byte[] buffer = new byte[8192];

            try
            {
                while (socket.State == WebSocketState.Open && !token.IsCancellationRequested)
                {
                    var result = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), token);
                    if (result.MessageType == WebSocketMessageType.Close) break;

                    string json = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    MessageReceived?.Invoke(json);
                }
            }
            catch (Exception e)
            {
                Disconnected?.Invoke(e.Message);
            }
        }

        public async void Disconnect()
        {
            try
            {
                cts?.Cancel();
                if (socket != null && socket.State == WebSocketState.Open)
                    await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "client_disconnect", CancellationToken.None);
            }
            catch { }
            finally
            {
                socket?.Dispose();
                cts?.Dispose();
                socket = null;
                cts = null;
                Disconnected?.Invoke("Disconnected");
            }
        }

        void OnDestroy() => Disconnect();
    }
}
