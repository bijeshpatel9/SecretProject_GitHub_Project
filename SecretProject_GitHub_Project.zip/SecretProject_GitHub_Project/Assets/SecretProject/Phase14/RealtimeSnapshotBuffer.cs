using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.Phase14
{
    public class RealtimeSnapshotBuffer
    {
        private struct Snapshot
        {
            public long tick;
            public Vector3 position;
            public float yaw;
        }

        private readonly List<Snapshot> buffer = new();
        private readonly int maxSnapshots;

        public RealtimeSnapshotBuffer(int maxSnapshots = 32)
        {
            this.maxSnapshots = Mathf.Max(4, maxSnapshots);
        }

        public void Add(NetworkPlayerState state)
        {
            if (state == null) return;
            buffer.Add(new Snapshot {
                tick = state.serverTick,
                position = state.position,
                yaw = state.yaw
            });

            if (buffer.Count > maxSnapshots)
                buffer.RemoveAt(0);
        }

        public bool TrySample(long targetTick, out Vector3 position, out float yaw)
        {
            position = default;
            yaw = 0f;

            if (buffer.Count == 0) return false;
            if (buffer.Count == 1)
            {
                position = buffer[0].position;
                yaw = buffer[0].yaw;
                return true;
            }

            Snapshot a = buffer[0], b = buffer[buffer.Count - 1];
            for (int i = 0; i < buffer.Count - 1; i++)
            {
                if (buffer[i].tick <= targetTick && targetTick <= buffer[i + 1].tick)
                {
                    a = buffer[i];
                    b = buffer[i + 1];
                    break;
                }
            }

            float t = a.tick == b.tick ? 1f : Mathf.InverseLerp(a.tick, b.tick, targetTick);
            position = Vector3.Lerp(a.position, b.position, t);
            yaw = Mathf.LerpAngle(a.yaw, b.yaw, t);
            return true;
        }
    }

    public class NetworkPlayerState
    {
        public string playerId;
        public Vector3 position;
        public float yaw;
        public long serverTick;
        public bool moving;
    }
}
