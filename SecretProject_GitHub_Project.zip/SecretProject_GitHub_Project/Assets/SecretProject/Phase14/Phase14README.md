# Secret Project — Phase 14
## Real-Time WebSocket Multiplayer Transport

Phase 14 introduces the real-time transport layer.

### Included
- Unity ClientWebSocket transport
- Auth/session hello message
- Heartbeat
- Receive loop
- Snapshot buffering
- Interpolation delay
- Remote player synchronization manager
- Bootstrap connect/disconnect

### Message flow
Client:
hello -> server
heartbeat -> server
movement intent -> server
server snapshot -> connected clients

### Local test
The default URL is:
ws://localhost:5000/ws

The Phase 11 HTTP server does NOT automatically provide `/ws`.
Use the Phase 14 server project included in this package for the WebSocket prototype.

### Production notes
- Use `wss://` with TLS.
- Authenticate the socket using the existing session token.
- Never trust client position.
- Validate ownership, sequence numbers, rate limits, world/zone membership and speed server-side.
- Keep the HTTP API for account/inventory/persistence operations; use real-time transport for gameplay state.
- For large MMO scale, add zone/shard routing and interest management.
