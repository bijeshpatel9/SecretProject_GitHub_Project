using System;

namespace SecretProject.Phase14
{
    [Serializable]
    public class RealtimeEnvelope
    {
        public string type;
        public string requestId;
        public string payload;
    }

    [Serializable]
    public class HelloPayload
    {
        public string playerId;
        public string sessionToken;
        public long clientTimeMs;
    }

    [Serializable]
    public class HeartbeatPayload
    {
        public long clientTimeMs;
    }

    [Serializable]
    public class PlayerSnapshotPayload
    {
        public string playerId;
        public float x;
        public float y;
        public float z;
        public float yaw;
        public long serverTick;
        public bool moving;
    }
}
