using System;
using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.Phase14
{
    public class RealtimeMultiplayerManager : MonoBehaviour
    {
        [SerializeField] private RealtimeWebSocketClient transport;
        [SerializeField] private RemotePlayerManager remotePlayers;
        [SerializeField] private int interpolationDelayTicks = 2;

        private readonly Dictionary<string, RealtimeSnapshotBuffer> buffers = new();
        private long latestServerTick;

        void Awake()
        {
            if (transport == null) transport = GetComponent<RealtimeWebSocketClient>();
            if (remotePlayers == null) remotePlayers = GetComponent<RemotePlayerManager>();
        }

        void OnEnable()
        {
            if (transport != null) transport.MessageReceived += HandleMessage;
        }

        void OnDisable()
        {
            if (transport != null) transport.MessageReceived -= HandleMessage;
        }

        void Update()
        {
            if (remotePlayers == null) return;

            foreach (var pair in buffers)
            {
                if (pair.Value.TrySample(latestServerTick - interpolationDelayTicks,
                    out var position, out var yaw))
                {
                    remotePlayers.ApplyState(new NetworkPlayerState {
                        playerId = pair.Key,
                        position = position,
                        yaw = yaw,
                        serverTick = latestServerTick - interpolationDelayTicks,
                        moving = true
                    });
                }
            }
        }

        private void HandleMessage(string json)
        {
            var envelope = JsonUtility.FromJson<RealtimeEnvelope>(json);
            if (envelope == null) return;

            if (envelope.type == "snapshot")
            {
                var p = JsonUtility.FromJson<PlayerSnapshotPayload>(envelope.payload);
                if (p == null || string.IsNullOrEmpty(p.playerId)) return;

                latestServerTick = Math.Max(latestServerTick, p.serverTick);

                if (!buffers.TryGetValue(p.playerId, out var buffer))
                {
                    buffer = new RealtimeSnapshotBuffer();
                    buffers[p.playerId] = buffer;
                }

                buffer.Add(new NetworkPlayerState {
                    playerId = p.playerId,
                    position = new Vector3(p.x, p.y, p.z),
                    yaw = p.yaw,
                    serverTick = p.serverTick,
                    moving = p.moving
                });
            }
        }
    }
}
