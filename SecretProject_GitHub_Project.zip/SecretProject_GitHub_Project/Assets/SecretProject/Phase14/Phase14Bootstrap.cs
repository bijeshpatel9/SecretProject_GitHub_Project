using UnityEngine;

namespace SecretProject.Phase14
{
    public class Phase14Bootstrap : MonoBehaviour
    {
        [SerializeField] private string websocketUrl = "ws://localhost:5000/ws";
        [SerializeField] private RealtimeWebSocketClient transport;

        void Awake()
        {
            if (transport == null)
                transport = GetComponent<RealtimeWebSocketClient>();

            if (transport == null)
                transport = gameObject.AddComponent<RealtimeWebSocketClient>();

            transport.SetUrl(websocketUrl);
        }

        public void Connect()
        {
            string playerId = PlayerPrefs.GetString("SecretProject_PlayerId", "anonymous");
            string token = PlayerPrefs.GetString("SecretProject_SessionToken", "");
            transport.Connect(playerId, token);
        }

        public void Disconnect() => transport.Disconnect();
    }
}
