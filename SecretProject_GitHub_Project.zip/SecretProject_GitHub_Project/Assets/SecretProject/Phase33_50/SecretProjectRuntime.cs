using System;using System.Collections.Generic;
namespace SecretProject.UnityRuntime {
 public sealed class ServerSnapshot {public long Version;public long Hp;public long Mana;public int Level;public string[] Skills=Array.Empty<string>();}
 public sealed class AuthoritativeStateBridge {public ServerSnapshot Current{get;private set;}=new();public void Apply(ServerSnapshot s){if(s.Version<Current.Version)return;Current=s;}public bool CanUseSkill(string id){foreach(var s in Current.Skills)if(s==id)return true;return false;}}
 public sealed class MobileHudBudget {public int TargetFps=60;public int ParticleLimit=500;public void Apply(int fps,int particles){TargetFps=fps;ParticleLimit=particles;}}
}
