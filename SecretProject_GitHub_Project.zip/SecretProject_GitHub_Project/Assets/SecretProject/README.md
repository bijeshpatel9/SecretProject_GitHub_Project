# Secret Project — Anime Fantasy MMO RPG

Platform: Android + iOS
Camera: Third-person
Visual direction: Anime 3D fantasy
Engine: Unity + C#

## Phase 1 starter
Included:
- Third-person character controller
- Camera follow + look input
- Mobile virtual joystick
- Basic health system
- Basic melee attack
- UI attack-button hook

## Unity setup
1. Create a new Unity 3D project.
2. Copy the `Assets/SecretProject` folder into the project's `Assets` folder.
3. Add a Player GameObject with:
   - CharacterController
   - ThirdPersonPlayerController
   - MobilePlayerInput
4. Add a Camera with ThirdPersonCamera and assign the Player as target.
5. Create a Canvas with a joystick:
   - Background object with VirtualJoystick
   - Child handle RectTransform
6. Add an attack button and connect its OnClick to `AttackButton.PressAttack`.
7. Put enemies on an Enemy layer and give them `Health`.
8. Assign the Enemy layer to PlayerAttack.enemyLayers.

## Next phases
Phase 2: enemy AI, animation state machine, target lock, skills, XP and level system.
Phase 3: inventory, equipment, quests, NPCs and loot.
Phase 4: online multiplayer architecture and persistent accounts.
Phase 5: MMO systems, guilds, party, chat, trading and PvP.
