using UnityEngine;

namespace SecretProject.Phase17
{
    public sealed class Phase17CombatPresenter : MonoBehaviour
    {
        [SerializeField] private ServerCombatClient client;
        [SerializeField] private string basicAttackId = "basic_attack";
        [SerializeField] private string currentTargetId;

        public void Attack()
        {
            if (client == null || string.IsNullOrWhiteSpace(currentTargetId)) return;
            client.SendAttack(basicAttackId, currentTargetId, transform.position + Vector3.up, transform.forward);
        }

        public void SetTarget(string targetId) => currentTargetId = targetId;
    }
}
