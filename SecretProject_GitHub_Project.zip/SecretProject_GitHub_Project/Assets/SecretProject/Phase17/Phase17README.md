# Secret Project — Phase 17
## Server-Authoritative Combat & Hit Validation

Goal: the client sends combat intent; the server decides whether a hit is legal and how much damage is applied.

Flow:
Client input -> CombatIntent -> authenticated server -> sequence/replay checks -> action/cooldown validation -> range/angle/LOS validation -> server damage calculation -> CombatResult -> client presentation.

Rules:
- Never trust client damage, hit result, cooldown, target HP, or critical-hit result.
- Client position is not authoritative; combine with Phase 15/16 authoritative movement state.
- Final boss rewards remain behind the Phase 10/11 transaction-safe reward path.
- Production should use the real WebSocket transport for intents/results rather than HTTP per attack.

Prototype setup: add ServerCombatClient and Phase17CombatPresenter to the player. Set the server endpoint, bearer token, player ID, and a target ID from your network target system.
