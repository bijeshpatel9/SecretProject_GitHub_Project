using System;
using UnityEngine;

namespace SecretProject.Phase17
{
    [Serializable]
    public sealed class CombatIntent
    {
        public string attackerId;
        public long sequence;
        public string actionId;
        public string targetId;
        public Vector3 origin;
        public Vector3 aimDirection;
        public long clientTick;
    }
}
