using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

namespace SecretProject.Phase17
{
    public sealed class ServerCombatClient : MonoBehaviour
    {
        [SerializeField] private string endpoint = "https://localhost:5001/v1/combat/action";
        [SerializeField] private string bearerToken;
        [SerializeField] private string playerId;
        private long sequence;

        public void SendAttack(string actionId, string targetId, Vector3 origin, Vector3 aimDirection)
        {
            var intent = new CombatIntent
            {
                attackerId = playerId,
                sequence = ++sequence,
                actionId = actionId,
                targetId = targetId,
                origin = origin,
                aimDirection = aimDirection.normalized,
                clientTick = Time.frameCount
            };
            StartCoroutine(Post(intent));
        }

        private IEnumerator Post(CombatIntent intent)
        {
            string json = JsonUtility.ToJson(intent);
            using var req = new UnityWebRequest(endpoint, UnityWebRequest.kHttpVerbPOST);
            byte[] body = System.Text.Encoding.UTF8.GetBytes(json);
            req.uploadHandler = new UploadHandlerRaw(body);
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            if (!string.IsNullOrWhiteSpace(bearerToken))
                req.SetRequestHeader("Authorization", "Bearer " + bearerToken);
            yield return req.SendWebRequest();
            if (req.result == UnityWebRequest.Result.Success)
                ApplyResult(JsonUtility.FromJson<CombatResult>(req.downloadHandler.text));
        }

        private void ApplyResult(CombatResult result)
        {
            // Only server-approved results may drive HP/reward changes.
            if (!result.accepted) return;
            Debug.Log($"Server hit confirmed: {result.targetId} -{result.damage}");
        }
    }
}
