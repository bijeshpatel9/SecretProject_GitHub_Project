using System;

namespace SecretProject.Phase17
{
    [Serializable]
    public sealed class CombatResult
    {
        public bool accepted;
        public string reason;
        public string attackerId;
        public string targetId;
        public int damage;
        public bool critical;
        public long serverTick;
    }
}
