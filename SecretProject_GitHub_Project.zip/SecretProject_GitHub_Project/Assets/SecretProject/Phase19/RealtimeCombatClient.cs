using System;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

public class RealtimeCombatClient : MonoBehaviour
{
    public string WebSocketUrl = "wss://localhost:5001/ws";
    ClientWebSocket socket;
    long sequence;

    public async Task SendAttackAsync(string targetId, string attackId)
    {
        if (socket == null || socket.State != WebSocketState.Open) return;
        var msg = JsonUtility.ToJson(new AttackIntent {
            type = "attack",
            sequence = ++sequence,
            targetId = targetId,
            attackId = attackId
        });
        var bytes = Encoding.UTF8.GetBytes(msg);
        await socket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
    }

    [Serializable] class AttackIntent
    {
        public string type;
        public long sequence;
        public string targetId;
        public string attackId;
    }
}