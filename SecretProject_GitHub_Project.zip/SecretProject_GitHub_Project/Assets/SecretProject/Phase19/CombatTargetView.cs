using UnityEngine;

public class CombatTargetView : MonoBehaviour
{
    public string EntityId;
    public Transform HitboxRoot;
    public float Radius = 0.75f;

    public void ApplyServerState(float health, float maxHealth, bool alive)
    {
        // Presentation only. Server remains authoritative.
    }
}