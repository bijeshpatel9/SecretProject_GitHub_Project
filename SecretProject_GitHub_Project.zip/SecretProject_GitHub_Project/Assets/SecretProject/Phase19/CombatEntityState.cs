using System;
using UnityEngine;

[Serializable]
public class CombatEntityState
{
    public string entityId;
    public Vector3 position;
    public float health;
    public float maxHealth;
    public bool alive;
}