using UnityEngine;

public class AoeCombatPresentation : MonoBehaviour
{
    public void ShowAffectedTargets(string[] entityIds)
    {
        // VFX/UI hook. Never calculate authoritative damage here.
    }
}