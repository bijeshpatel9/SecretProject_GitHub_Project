using System;

[Serializable]
public class ServerCombatMessage
{
    public string type;
    public string attackerId;
    public string targetId;
    public long sequence;
    public float damage;
    public bool critical;
    public string[] affectedEntityIds;
}