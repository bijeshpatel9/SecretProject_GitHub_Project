using UnityEngine;

namespace SecretProject.Phase13
{
    public enum NetworkConnectionState
    {
        Disconnected,
        Connecting,
        Connected,
        Reconnecting
    }

    public class NetworkConnectionStateController : MonoBehaviour
    {
        public NetworkConnectionState State { get; private set; } = NetworkConnectionState.Disconnected;
        public int ReconnectAttempts { get; private set; }

        public void SetConnecting() => State = NetworkConnectionState.Connecting;
        public void SetConnected()
        {
            State = NetworkConnectionState.Connected;
            ReconnectAttempts = 0;
        }

        public void SetDisconnected() => State = NetworkConnectionState.Disconnected;

        public void BeginReconnect()
        {
            State = NetworkConnectionState.Reconnecting;
            ReconnectAttempts++;
        }
    }
}
