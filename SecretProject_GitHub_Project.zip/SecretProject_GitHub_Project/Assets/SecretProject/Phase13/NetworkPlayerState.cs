using System;
using UnityEngine;

namespace SecretProject.Phase13
{
    [Serializable]
    public class NetworkPlayerState
    {
        public string playerId;
        public Vector3 position;
        public float yaw;
        public long serverTick;
        public bool moving;
    }
}
