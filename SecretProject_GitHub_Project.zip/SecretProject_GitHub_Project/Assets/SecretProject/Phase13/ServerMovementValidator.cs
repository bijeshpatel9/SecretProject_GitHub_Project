using UnityEngine;

namespace SecretProject.Phase13
{
    public class ServerMovementValidator
    {
        public float MaxSpeed { get; set; } = 8f;
        public float PositionTolerance { get; set; } = 2.5f;

        public bool Validate(NetworkPlayerState previous, MovementInput input, float deltaTime, out Vector3 acceptedPosition)
        {
            acceptedPosition = previous != null ? previous.position : input.position;
            if (previous == null || input == null || deltaTime <= 0f) return false;

            Vector3 delta = input.position - previous.position;
            float maxDistance = MaxSpeed * deltaTime + PositionTolerance;

            if (delta.magnitude > maxDistance)
                return false;

            acceptedPosition = input.position;
            return true;
        }
    }
}
