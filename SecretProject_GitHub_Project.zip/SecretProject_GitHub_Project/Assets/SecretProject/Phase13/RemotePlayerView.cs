using UnityEngine;

namespace SecretProject.Phase13
{
    public class RemotePlayerView : MonoBehaviour
    {
        [SerializeField] private float interpolationSpeed = 12f;
        private Vector3 targetPosition;
        private Quaternion targetRotation;
        private bool initialized;

        public string PlayerId { get; private set; }

        public void Initialize(string playerId, Vector3 position, float yaw)
        {
            PlayerId = playerId;
            targetPosition = position;
            targetRotation = Quaternion.Euler(0f, yaw, 0f);
            transform.SetPositionAndRotation(position, targetRotation);
            initialized = true;
        }

        public void ApplyState(NetworkPlayerState state)
        {
            if (!initialized) Initialize(state.playerId, state.position, state.yaw);
            targetPosition = state.position;
            targetRotation = Quaternion.Euler(0f, state.yaw, 0f);
        }

        void Update()
        {
            if (!initialized) return;
            transform.position = Vector3.Lerp(transform.position, targetPosition,
                1f - Mathf.Exp(-interpolationSpeed * Time.deltaTime));
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation,
                1f - Mathf.Exp(-interpolationSpeed * Time.deltaTime));
        }
    }
}
