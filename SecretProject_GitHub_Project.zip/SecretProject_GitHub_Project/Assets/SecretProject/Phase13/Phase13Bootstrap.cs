using UnityEngine;

namespace SecretProject.Phase13
{
    public class Phase13Bootstrap : MonoBehaviour
    {
        [SerializeField] private RemotePlayerManager remotePlayers;
        [SerializeField] private NetworkMovementClient movementClient;

        void Awake()
        {
            if (GetComponent<NetworkConnectionStateController>() == null)
                gameObject.AddComponent<NetworkConnectionStateController>();

            if (movementClient == null)
                movementClient = GetComponent<NetworkMovementClient>();

            if (remotePlayers == null)
                remotePlayers = GetComponent<RemotePlayerManager>();
        }

        public void SimulateRemoteState(string playerId, Vector3 position, float yaw)
        {
            if (remotePlayers == null) return;
            remotePlayers.ApplyState(new NetworkPlayerState
            {
                playerId = playerId,
                position = position,
                yaw = yaw,
                serverTick = 0,
                moving = false
            });
        }
    }
}
