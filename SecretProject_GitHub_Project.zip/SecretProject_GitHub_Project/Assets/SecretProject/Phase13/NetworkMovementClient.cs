using System;
using System.Collections;
using UnityEngine;

namespace SecretProject.Phase13
{
    public class NetworkMovementClient : MonoBehaviour
    {
        [SerializeField] private float sendInterval = 0.10f;
        [SerializeField] private float minimumPositionDelta = 0.02f;

        private float timer;
        private Vector3 lastSentPosition;
        private long tick;

        public Func<Vector3> PositionProvider { get; set; }
        public Func<float> YawProvider { get; set; }
        public Func<Vector3> VelocityProvider { get; set; }

        void Update()
        {
            if (ApiClientMissing()) return;
            timer += Time.deltaTime;
            if (timer < sendInterval) return;
            timer = 0f;

            Vector3 pos = PositionProvider != null ? PositionProvider() : transform.position;
            if ((pos - lastSentPosition).sqrMagnitude < minimumPositionDelta * minimumPositionDelta)
                return;

            lastSentPosition = pos;
            tick++;

            var input = new MovementInput
            {
                playerId = GetPlayerId(),
                position = pos,
                yaw = YawProvider != null ? YawProvider() : transform.eulerAngles.y,
                velocity = VelocityProvider != null ? VelocityProvider() : Vector3.zero,
                clientTick = tick
            };

            StartCoroutine(SendMovement(input));
        }

        private IEnumerator SendMovement(MovementInput input)
        {
            // Phase 13 client transport hook.
            // Phase 14 should use a persistent WebSocket/UDP-like transport.
            yield return null;
        }

        private string GetPlayerId()
        {
            return PlayerPrefs.GetString("SecretProject_PlayerId", "anonymous");
        }

        private bool ApiClientMissing()
        {
            return ApiClient.Instance == null;
        }
    }
}
