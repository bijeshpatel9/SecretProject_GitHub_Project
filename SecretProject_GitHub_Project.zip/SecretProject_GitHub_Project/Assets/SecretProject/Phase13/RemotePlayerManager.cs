using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.Phase13
{
    public class RemotePlayerManager : MonoBehaviour
    {
        [SerializeField] private RemotePlayerView remotePlayerPrefab;
        private readonly Dictionary<string, RemotePlayerView> players = new();

        public void ApplyState(NetworkPlayerState state)
        {
            if (state == null || string.IsNullOrEmpty(state.playerId)) return;

            if (!players.TryGetValue(state.playerId, out var view) || view == null)
            {
                if (remotePlayerPrefab == null) return;
                view = Instantiate(remotePlayerPrefab, state.position, Quaternion.Euler(0, state.yaw, 0), transform);
                view.Initialize(state.playerId, state.position, state.yaw);
                players[state.playerId] = view;
            }

            view.ApplyState(state);
        }

        public void RemovePlayer(string playerId)
        {
            if (string.IsNullOrEmpty(playerId)) return;
            if (players.TryGetValue(playerId, out var view))
            {
                if (view != null) Destroy(view.gameObject);
                players.Remove(playerId);
            }
        }

        public void ClearAll()
        {
            foreach (var pair in players)
                if (pair.Value != null) Destroy(pair.Value.gameObject);
            players.Clear();
        }
    }
}
