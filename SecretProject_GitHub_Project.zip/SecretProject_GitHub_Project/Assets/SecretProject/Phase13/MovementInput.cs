using System;
using UnityEngine;

namespace SecretProject.Phase13
{
    [Serializable]
    public class MovementInput
    {
        public string playerId;
        public Vector3 position;
        public float yaw;
        public Vector3 velocity;
        public long clientTick;
    }
}
