using UnityEngine;

namespace SecretProject.Phase15
{
    public class Phase15Bootstrap : MonoBehaviour
    {
        void Awake()
        {
            if (GetComponent<AuthoritativeMovementClient>() == null)
                gameObject.AddComponent<AuthoritativeMovementClient>();

            if (GetComponent<AuthoritativeMovementReconciler>() == null)
                gameObject.AddComponent<AuthoritativeMovementReconciler>();
        }
    }
}
