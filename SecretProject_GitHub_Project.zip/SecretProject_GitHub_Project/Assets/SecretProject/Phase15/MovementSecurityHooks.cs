using UnityEngine;

namespace SecretProject.Phase15
{
    public static class MovementSecurityHooks
    {
        public static bool IsReasonableInput(Vector3 input)
        {
            return input.sqrMagnitude <= 1.01f && Mathf.Abs(input.y) < 0.01f;
        }

        public static bool IsReasonableYaw(float yaw)
        {
            return !float.IsNaN(yaw) && !float.IsInfinity(yaw);
        }
    }
}
