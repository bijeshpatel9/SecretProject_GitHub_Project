using System;
using UnityEngine;

namespace SecretProject.Phase15
{
    public class AuthoritativeMovementClient : MonoBehaviour
    {
        [SerializeField] private float inputSendRate = 20f;
        private float timer;
        private long clientTick;

        public Func<Vector3> InputProvider { get; set; }
        public Func<float> YawProvider { get; set; }
        public Func<bool> SprintProvider { get; set; }

        public event Action<MovementIntent> IntentReady;

        void Update()
        {
            timer += Time.deltaTime;
            if (timer < 1f / Mathf.Max(1f, inputSendRate)) return;
            timer = 0f;

            Vector3 input = InputProvider != null ? InputProvider() : Vector3.zero;
            input = Vector3.ClampMagnitude(new Vector3(input.x, 0f, input.z), 1f);

            IntentReady?.Invoke(new MovementIntent {
                playerId = PlayerPrefs.GetString("SecretProject_PlayerId", "anonymous"),
                clientTick = ++clientTick,
                inputDirection = input,
                requestedYaw = YawProvider != null ? YawProvider() : transform.eulerAngles.y,
                wantsSprint = SprintProvider != null && SprintProvider()
            });
        }
    }
}
