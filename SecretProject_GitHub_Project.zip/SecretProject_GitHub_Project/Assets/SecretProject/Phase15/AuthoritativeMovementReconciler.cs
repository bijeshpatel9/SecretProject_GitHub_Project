using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.Phase15
{
    public class AuthoritativeMovementReconciler : MonoBehaviour
    {
        [SerializeField] private float correctionSharpness = 14f;
        [SerializeField] private float snapDistance = 3f;

        private readonly Queue<MovementIntent> pending = new();
        private Vector3 authoritativePosition;
        private bool hasServerState;

        public void TrackIntent(MovementIntent intent)
        {
            if (intent != null) pending.Enqueue(intent);
        }

        public void ApplyServerPosition(Vector3 position, long acknowledgedClientTick)
        {
            authoritativePosition = position;

            while (pending.Count > 0 && pending.Peek().clientTick <= acknowledgedClientTick)
                pending.Dequeue();

            if (!hasServerState)
            {
                transform.position = position;
                hasServerState = true;
                return;
            }

            float distance = Vector3.Distance(transform.position, position);
            if (distance >= snapDistance)
                transform.position = position;
            else
                transform.position = Vector3.Lerp(transform.position, position,
                    1f - Mathf.Exp(-correctionSharpness * Time.deltaTime));
        }
    }
}
