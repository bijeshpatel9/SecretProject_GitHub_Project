using System.IO;
using UnityEngine;

namespace SecretProject.Backend
{
    public class LocalPlayerRepository : IPlayerRepository
    {
        readonly string folder;

        public LocalPlayerRepository()
        {
            folder = Path.Combine(Application.persistentDataPath, "SecretProjectSaves");
            Directory.CreateDirectory(folder);
        }

        string PathFor(string playerId)
        {
            return Path.Combine(folder, playerId + ".json");
        }

        public PlayerSaveData Load(string playerId)
        {
            string path = PathFor(playerId);
            if (!File.Exists(path)) return null;
            return PlayerSaveSerializer.Deserialize(File.ReadAllText(path));
        }

        public bool Save(PlayerSaveData data)
        {
            if (data == null || string.IsNullOrEmpty(data.playerId)) return false;
            File.WriteAllText(PathFor(data.playerId), PlayerSaveSerializer.Serialize(data));
            return true;
        }
    }
}