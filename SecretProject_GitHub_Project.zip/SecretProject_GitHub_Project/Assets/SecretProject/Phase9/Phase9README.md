# Secret Project — Phase 9: Persistent MMO Backend Foundation

## Included
- Player save data model
- JSON serialization
- Repository abstraction
- Local persistent repository prototype
- Player login/create flow
- Inventory persistence
- Session/authentication model
- Boss defeat persistence
- SS+ skill ownership persistence
- Bootstrap

## Persistence flow
Authenticated Player
 -> Server Validation
 -> Player Backend Service
 -> Repository / Database
 -> Persistent Player State

## Security
The included LocalPlayerRepository is only a development prototype.
A production MMO must NOT trust client-side save files.

Production architecture should use:
- Dedicated authoritative server
- Secure authentication provider
- Database (SQL/NoSQL)
- Server-issued sessions/tokens
- Transactional boss reward writes
- Unique constraint on (playerId, bossId)
- Server-authoritative SS+ skill ownership
- Inventory transaction validation
- Rate limiting and audit logs

## Boss rule
Each special boss defeat must be validated by the authoritative server before
the persistent boss-defeat record and SS+ skill unlock are committed.

## Unity setup
Create a backend/network manager GameObject and add:
PlayerBackendService
InventoryService
AuthenticationSessionService
ServerBossPersistence
Phase9Bootstrap

## Next
Phase 10 can build production-style server API contracts, database schema,
transaction-safe reward claiming, inventory transactions, and MMO-ready
client/server message models.
