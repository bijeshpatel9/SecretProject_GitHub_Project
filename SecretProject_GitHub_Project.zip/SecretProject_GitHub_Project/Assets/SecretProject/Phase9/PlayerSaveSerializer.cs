using UnityEngine;

namespace SecretProject.Backend
{
    public static class PlayerSaveSerializer
    {
        public static string Serialize(PlayerSaveData data)
        {
            return JsonUtility.ToJson(data, true);
        }

        public static PlayerSaveData Deserialize(string json)
        {
            if (string.IsNullOrEmpty(json)) return null;
            return JsonUtility.FromJson<PlayerSaveData>(json);
        }
    }
}