namespace SecretProject.Backend
{
    public interface IPlayerRepository
    {
        PlayerSaveData Load(string playerId);
        bool Save(PlayerSaveData data);
    }
}