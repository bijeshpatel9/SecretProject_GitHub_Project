using UnityEngine;

namespace SecretProject.Backend
{
    public class InventoryService : MonoBehaviour
    {
        public PlayerBackendService backend;

        void Awake()
        {
            if (backend == null) backend = GetComponent<PlayerBackendService>();
        }

        public bool AddItem(string itemId)
        {
            if (backend?.Current == null || string.IsNullOrEmpty(itemId)) return false;
            backend.Current.inventory.Add(itemId);
            return backend.Save();
        }

        public bool HasItem(string itemId)
        {
            return backend?.Current != null &&
                   backend.Current.inventory.Contains(itemId);
        }

        public bool RemoveItem(string itemId)
        {
            if (backend?.Current == null) return false;
            if (!backend.Current.inventory.Remove(itemId)) return false;
            return backend.Save();
        }
    }
}