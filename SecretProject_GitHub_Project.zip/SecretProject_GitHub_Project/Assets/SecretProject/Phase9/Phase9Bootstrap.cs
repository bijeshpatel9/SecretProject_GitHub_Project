using UnityEngine;

namespace SecretProject.Backend
{
    public class Phase9Bootstrap : MonoBehaviour
    {
        public PlayerBackendService playerBackend;
        public InventoryService inventory;
        public AuthenticationSessionService sessions;
        public ServerBossPersistence bossPersistence;

        void Awake()
        {
            if (playerBackend == null) playerBackend = GetComponent<PlayerBackendService>();
            if (inventory == null) inventory = GetComponent<InventoryService>();
            if (sessions == null) sessions = GetComponent<AuthenticationSessionService>();
            if (bossPersistence == null) bossPersistence = GetComponent<ServerBossPersistence>();
        }

        void Start()
        {
            if (playerBackend != null)
                playerBackend.LoginOrCreate("LOCAL_PROTOTYPE_PLAYER");
        }
    }
}