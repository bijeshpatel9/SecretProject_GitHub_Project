using System;
using UnityEngine;

namespace SecretProject.Backend
{
    [Serializable]
    public class AuthenticationSession
    {
        public string playerId;
        public string sessionToken;
        public long createdUnixTime;
        public long expiresUnixTime;
    }

    public class AuthenticationSessionService : MonoBehaviour
    {
        public AuthenticationSession CurrentSession { get; private set; }

        public bool CreatePrototypeSession(string playerId, string serverIssuedToken)
        {
            if (string.IsNullOrEmpty(playerId) || string.IsNullOrEmpty(serverIssuedToken))
                return false;

            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            CurrentSession = new AuthenticationSession
            {
                playerId = playerId,
                sessionToken = serverIssuedToken,
                createdUnixTime = now,
                expiresUnixTime = now + 3600
            };
            return true;
        }

        public bool IsSessionValid()
        {
            return CurrentSession != null &&
                   DateTimeOffset.UtcNow.ToUnixTimeSeconds() < CurrentSession.expiresUnixTime;
        }
    }
}