using System;
using System.Collections.Generic;

namespace SecretProject.Backend
{
    [Serializable]
    public class PlayerSaveData
    {
        public string playerId;
        public int level = 1;
        public long experience;
        public int gold;
        public List<string> inventory = new List<string>();
        public List<string> unlockedSkills = new List<string>();
        public List<string> defeatedBossIds = new List<string>();
    }
}