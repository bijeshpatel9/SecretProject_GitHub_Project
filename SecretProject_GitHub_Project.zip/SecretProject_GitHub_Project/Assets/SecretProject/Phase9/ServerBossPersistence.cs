using UnityEngine;

namespace SecretProject.Backend
{
    public class ServerBossPersistence : MonoBehaviour
    {
        public PlayerBackendService backend;

        public bool CommitBossDefeat(string playerId, string bossId, string ssPlusSkillId)
        {
            if (backend == null || backend.Current == null) return false;
            if (backend.Current.playerId != playerId) return false;

            // Production server must perform the defeat validation before this call.
            return backend.RecordBossDefeat(bossId, ssPlusSkillId);
        }
    }
}