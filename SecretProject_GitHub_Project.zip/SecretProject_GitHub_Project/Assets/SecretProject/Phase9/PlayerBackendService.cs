using UnityEngine;

namespace SecretProject.Backend
{
    public class PlayerBackendService : MonoBehaviour
    {
        public PlayerSaveData Current { get; private set; }
        IPlayerRepository repository;

        void Awake()
        {
            repository = new LocalPlayerRepository();
        }

        public bool LoginOrCreate(string playerId)
        {
            if (string.IsNullOrEmpty(playerId)) return false;

            Current = repository.Load(playerId);
            if (Current == null)
            {
                Current = new PlayerSaveData { playerId = playerId };
                return repository.Save(Current);
            }
            return true;
        }

        public bool Save()
        {
            return Current != null && repository.Save(Current);
        }

        public bool HasSkill(string skillId)
        {
            return Current != null && Current.unlockedSkills.Contains(skillId);
        }

        public bool HasDefeatedBoss(string bossId)
        {
            return Current != null && Current.defeatedBossIds.Contains(bossId);
        }

        public bool RecordBossDefeat(string bossId, string skillId)
        {
            if (Current == null || string.IsNullOrEmpty(bossId)) return false;
            if (Current.defeatedBossIds.Contains(bossId)) return false;

            Current.defeatedBossIds.Add(bossId);

            if (!string.IsNullOrEmpty(skillId) && !Current.unlockedSkills.Contains(skillId))
                Current.unlockedSkills.Add(skillId);

            return Save();
        }
    }
}