using UnityEngine;

namespace SecretProject.Phase22;

public sealed class WorldBossRecoveryClient : MonoBehaviour
{
    public bool IsRecovering { get; private set; }

    public void BeginRecovery()
    {
        IsRecovering = true;
    }

    public void ApplyRecoveredBossState(string instanceId, Vector3 position, float health, int phase, bool active)
    {
        IsRecovering = false;
        // Presentation layer should apply the server snapshot here.
        // Client never decides authoritative HP/phase.
    }

    public void RejectRecovery()
    {
        IsRecovering = false;
    }
}
