using UnityEngine;

namespace SecretProject.Phase22;

public sealed class Phase22Bootstrap : MonoBehaviour
{
    [SerializeField] private WorldBossRecoveryClient recoveryClient;

    private void Awake()
    {
        if (recoveryClient == null)
            recoveryClient = GetComponent<WorldBossRecoveryClient>();

        if (recoveryClient == null)
            recoveryClient = gameObject.AddComponent<WorldBossRecoveryClient>();
    }
}
