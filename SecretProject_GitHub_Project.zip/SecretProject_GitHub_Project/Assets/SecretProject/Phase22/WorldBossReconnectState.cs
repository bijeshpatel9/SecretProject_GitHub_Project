using System;

namespace SecretProject.Phase22;

[Serializable]
public sealed class WorldBossReconnectState
{
    public string WorldId;
    public string ShardId;
    public string ZoneId;
    public string InstanceId;
    public long LastServerTick;
    public bool AwaitingRecovery;
}
