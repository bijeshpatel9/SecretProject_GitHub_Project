using UnityEngine;
namespace SecretProject.Phase27;
public sealed class Phase27Bootstrap:MonoBehaviour { [SerializeField] DistributedSessionClient sessionClient; void Awake(){if(sessionClient==null)sessionClient=GetComponent<DistributedSessionClient>();if(sessionClient==null)sessionClient=gameObject.AddComponent<DistributedSessionClient>();} }
