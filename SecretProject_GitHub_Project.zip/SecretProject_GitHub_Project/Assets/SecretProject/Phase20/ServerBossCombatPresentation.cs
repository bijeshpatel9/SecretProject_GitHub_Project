using UnityEngine;

namespace SecretProject.Unity.BossCombat
{
    public sealed class ServerBossCombatPresentation : MonoBehaviour
    {
        [SerializeField] private Animator animator;
        [SerializeField] private ParticleSystem enrageEffect;

        public void ApplyPhase(int phase)
        {
            if (animator != null) animator.SetInteger("BossPhase", phase);
        }

        public void ApplyEnrage(bool enraged)
        {
            if (enrageEffect == null) return;
            if (enraged && !enrageEffect.isPlaying) enrageEffect.Play();
            if (!enraged && enrageEffect.isPlaying) enrageEffect.Stop();
        }
    }
}
