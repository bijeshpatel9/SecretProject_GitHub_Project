using System;
using UnityEngine;

namespace SecretProject.Unity.BossCombat
{
    public sealed class BossServerCombatClient : MonoBehaviour
    {
        public event Action<string, int, bool> OnAuthoritativeBossState;
        public event Action<string, int> OnBossAttackResult;

        public void ReceiveBossState(string instanceId, int hp, int phase, bool enraged)
            => OnAuthoritativeBossState?.Invoke(instanceId, hp, enraged);

        public void ReceiveBossAttack(string attackId, int damage)
            => OnBossAttackResult?.Invoke(attackId, damage);
    }
}
