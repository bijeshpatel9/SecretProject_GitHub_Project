using System;
using System.Collections;
using UnityEngine;
using SecretProject.Phase12;

namespace SecretProject.Phase12
{
    public class AuthenticationClient : MonoBehaviour
    {
        public string PlayerId { get; private set; }
        public bool IsAuthenticated => !string.IsNullOrEmpty(PlayerId) && !string.IsNullOrEmpty(ApiClient.Instance?.SessionToken);

        public void Login(string deviceId, Action onSuccess = null, Action<string> onError = null)
        {
            StartCoroutine(ApiClient.Instance.Send<SessionResponse>(
                "POST", "/v1/auth/session",
                JsonUtility.ToJson(new SessionRequest { deviceId = deviceId }),
                response =>
                {
                    PlayerId = response.playerId;
                    ApiClient.Instance.SetSessionToken(response.token);
                    onSuccess?.Invoke();
                },
                onError));
        }
    }
}
