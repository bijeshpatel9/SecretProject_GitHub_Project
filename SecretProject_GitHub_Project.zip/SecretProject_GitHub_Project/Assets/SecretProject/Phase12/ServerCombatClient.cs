using System;
using UnityEngine;

namespace SecretProject.Phase12
{
    public class ServerCombatClient : MonoBehaviour
    {
        private int sequence;

        public void SubmitAction(string actionId, string targetId, Action<CombatResult> onResult, Action<string> onError = null)
        {
            var request = new CombatActionRequest {
                actionId = actionId,
                targetId = targetId,
                clientSequence = ++sequence
            };

            StartCoroutine(ApiClient.Instance.Send<CombatResult>(
                "POST", "/v1/combat/action", JsonUtility.ToJson(request),
                onResult, onError));
        }
    }
}
