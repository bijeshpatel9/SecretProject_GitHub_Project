using System;
using UnityEngine;

namespace SecretProject.Phase12
{
    public class BossRewardClient : MonoBehaviour
    {
        public void CommitReward(string bossId, string skillId, Action<BossRewardResponse> onSuccess, Action<string> onError = null)
        {
            var request = new BossRewardRequest { bossId = bossId, rewardSkillId = skillId };
            StartCoroutine(ApiClient.Instance.Send<BossRewardResponse>(
                "POST", "/v1/boss/reward/commit", JsonUtility.ToJson(request),
                onSuccess, onError));
        }
    }
}
