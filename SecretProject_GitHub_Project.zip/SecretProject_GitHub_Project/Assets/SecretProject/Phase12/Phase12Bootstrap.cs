using UnityEngine;

namespace SecretProject.Phase12
{
    public class Phase12Bootstrap : MonoBehaviour
    {
        [SerializeField] private string serverUrl = "http://localhost:5000";

        void Awake()
        {
            if (ApiClient.Instance == null)
            {
                var api = new GameObject("ApiClient");
                api.AddComponent<ApiClient>();
            }

            ApiClient.Instance.SetBaseUrl(serverUrl);

            if (GetComponent<AuthenticationClient>() == null) gameObject.AddComponent<AuthenticationClient>();
            if (GetComponent<PlayerSyncClient>() == null) gameObject.AddComponent<PlayerSyncClient>();
            if (GetComponent<ServerCombatClient>() == null) gameObject.AddComponent<ServerCombatClient>();
            if (GetComponent<BossRewardClient>() == null) gameObject.AddComponent<BossRewardClient>();
        }

        public void LoginAndSync()
        {
            string deviceId = SystemInfo.deviceUniqueIdentifier;
            var auth = GetComponent<AuthenticationClient>();
            var sync = GetComponent<PlayerSyncClient>();

            auth.Login(deviceId,
                () => sync.Refresh(
                    snapshot => Debug.Log($"Server sync OK. Level={snapshot.level}, Gold={snapshot.gold}"),
                    error => Debug.LogError("Snapshot failed: " + error)),
                error => Debug.LogError("Login failed: " + error));
        }
    }
}
