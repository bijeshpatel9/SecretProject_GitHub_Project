using System;
using System.Collections;
using UnityEngine;

namespace SecretProject.Phase12
{
    public class PlayerSyncClient : MonoBehaviour
    {
        public PlayerSnapshot Current { get; private set; }

        public void Refresh(Action<PlayerSnapshot> onSuccess = null, Action<string> onError = null)
        {
            StartCoroutine(ApiClient.Instance.Send<PlayerSnapshot>(
                "GET", "/v1/player/snapshot", null,
                snapshot => { Current = snapshot; onSuccess?.Invoke(snapshot); },
                onError));
        }
    }
}
