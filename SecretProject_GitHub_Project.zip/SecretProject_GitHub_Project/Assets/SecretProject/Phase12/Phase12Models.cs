using System;

namespace SecretProject.Phase12
{
    [Serializable] public class SessionRequest { public string deviceId; }
    [Serializable] public class SessionResponse { public string playerId; public string token; }

    [Serializable] public class PlayerSnapshot
    {
        public string playerId;
        public int level;
        public long xp;
        public long gold;
        public string[] skills;
        public string[] inventory;
        public string[] defeatedBosses;
    }

    [Serializable] public class BossRewardRequest
    {
        public string bossId;
        public string rewardSkillId;
    }

    [Serializable] public class BossRewardResponse
    {
        public bool success;
        public bool alreadyClaimed;
        public string message;
    }

    [Serializable] public class CombatActionRequest
    {
        public string actionId;
        public string targetId;
        public int clientSequence;
    }

    [Serializable] public class CombatResult
    {
        public bool accepted;
        public int serverSequence;
        public int damage;
        public string reason;
    }
}
