# Secret Project — Phase 12
## Unity Client ↔ Production Server Connection

This phase connects the Unity client to the Phase 11 ASP.NET Core server.

### Included
- ApiClient using UnityWebRequest
- Bearer session token handling
- Login/session request
- Player snapshot synchronization
- Server combat action request bridge
- One-time boss reward commit client
- Phase12Bootstrap for quick scene setup

### Scene setup
1. Start the Phase 11 server.
2. Create an empty GameObject named `Phase12Bootstrap`.
3. Add `Phase12Bootstrap.cs`.
4. Set Server URL:
   - Editor/local: `http://localhost:5000`
   - Android emulator talking to PC: commonly `http://10.0.2.2:5000`
   - Physical phone: use the PC's LAN IP and configure the server/firewall.
5. Call `LoginAndSync()` from a temporary UI button or test script.

### Important production notes
- HTTPS is required for production.
- Do not use `SystemInfo.deviceUniqueIdentifier` as a real identity system.
- Use a real authentication provider/account ID.
- Combat must be validated/simulated server-side; client requests are only intents.
- Boss rewards must remain server-authoritative and idempotent.
- Add reconnect, timeout, retry, matchmaking/session lifecycle, clock synchronization, and network interpolation in later phases.

### Current endpoint dependency
The Phase 11 server already exposes:
POST /v1/auth/session
GET  /v1/player/snapshot
POST /v1/boss/reward/commit

The combat client also expects:
POST /v1/combat/action

If the Phase 11 server does not yet implement that endpoint, combat submission will correctly fail until the server endpoint is added.
