using System;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace SecretProject.Phase12
{
    public class ApiClient : MonoBehaviour
    {
        public static ApiClient Instance { get; private set; }
        [SerializeField] private string baseUrl = "http://localhost:5000";

        public string BaseUrl => baseUrl;
        public string SessionToken { get; private set; }

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        public void SetBaseUrl(string url) => baseUrl = url.TrimEnd('/');
        public void SetSessionToken(string token) => SessionToken = token;

        public IEnumerator Send<T>(string method, string path, string json, Action<T> onSuccess, Action<string> onError)
        {
            using var req = new UnityWebRequest(baseUrl + path, method);
            if (!string.IsNullOrEmpty(json))
            {
                byte[] body = Encoding.UTF8.GetBytes(json);
                req.uploadHandler = new UploadHandlerRaw(body);
            }
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            if (!string.IsNullOrEmpty(SessionToken))
                req.SetRequestHeader("Authorization", "Bearer " + SessionToken);

            yield return req.SendWebRequest();

            if (req.result != UnityWebRequest.Result.Success)
            {
                onError?.Invoke($"HTTP {(int)req.responseCode}: {req.error}\n{req.downloadHandler.text}");
                yield break;
            }

            try { onSuccess?.Invoke(JsonUtility.FromJson<T>(req.downloadHandler.text)); }
            catch (Exception e) { onError?.Invoke("Invalid server response: " + e.Message); }
        }
    }
}
