using System;
using UnityEngine;

namespace SecretProject.Phase21
{
    [Serializable]
    public class BossInstanceState
    {
        public string BossId;
        public string InstanceId;
        public string WorldId;
        public string ZoneId;
        public float Health;
        public float MaxHealth;
        public int Phase;
        public bool Defeated;
        public bool Active;
        public Vector3 Position;
        public long SpawnTick;
    }
}
