using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.Phase21
{
    public class ServerBossInstanceClient : MonoBehaviour
    {
        private readonly Dictionary<string, BossInstanceState> instances =
            new Dictionary<string, BossInstanceState>();

        public void ApplySnapshot(BossInstanceState state)
        {
            if (state == null || string.IsNullOrWhiteSpace(state.InstanceId))
                return;

            instances[state.InstanceId] = state;
        }

        public bool TryGet(string instanceId, out BossInstanceState state)
        {
            return instances.TryGetValue(instanceId, out state);
        }

        public void Remove(string instanceId)
        {
            instances.Remove(instanceId);
        }
    }
}
