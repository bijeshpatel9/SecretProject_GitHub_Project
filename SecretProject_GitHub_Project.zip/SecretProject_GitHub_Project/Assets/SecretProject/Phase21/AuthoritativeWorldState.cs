using System;
using UnityEngine;

namespace SecretProject.Phase21
{
    [Serializable]
    public struct WorldPosition
    {
        public string ZoneId;
        public Vector3 Position;

        public WorldPosition(string zoneId, Vector3 position)
        {
            ZoneId = zoneId;
            Position = position;
        }
    }

    [Serializable]
    public class AuthoritativeWorldState
    {
        public string WorldId;
        public string ShardId;
        public long ServerTick;
    }
}
