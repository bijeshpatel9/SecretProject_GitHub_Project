using UnityEngine;

namespace SecretProject.Phase21
{
    public class Phase21Bootstrap : MonoBehaviour
    {
        [SerializeField] private ServerBossInstanceClient bossClient;

        private void Awake()
        {
            if (bossClient == null)
                bossClient = GetComponent<ServerBossInstanceClient>();

            if (bossClient == null)
                bossClient = gameObject.AddComponent<ServerBossInstanceClient>();
        }
    }
}
