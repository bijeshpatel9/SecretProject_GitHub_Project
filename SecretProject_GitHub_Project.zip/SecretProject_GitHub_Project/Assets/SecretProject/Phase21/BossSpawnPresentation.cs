using UnityEngine;

namespace SecretProject.Phase21
{
    public class BossSpawnPresentation : MonoBehaviour
    {
        public void OnAuthoritativeBossSpawn(BossInstanceState state)
        {
            if (state == null) return;
            transform.position = state.Position;
            gameObject.SetActive(state.Active && !state.Defeated);
        }

        public void OnAuthoritativeBossState(BossInstanceState state)
        {
            if (state == null) return;
            transform.position = state.Position;
            gameObject.SetActive(state.Active && !state.Defeated);
        }
    }
}
