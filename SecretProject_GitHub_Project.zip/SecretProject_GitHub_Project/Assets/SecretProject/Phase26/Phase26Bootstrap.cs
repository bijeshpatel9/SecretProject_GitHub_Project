using UnityEngine;

namespace SecretProject.Phase26;

public sealed class Phase26Bootstrap : MonoBehaviour
{
    [SerializeField] private PlayerTransferClient transferClient;

    private void Awake()
    {
        if (transferClient==null) transferClient=GetComponent<PlayerTransferClient>();
        if (transferClient==null) transferClient=gameObject.AddComponent<PlayerTransferClient>();
    }
}
