using UnityEngine;

namespace SecretProject.Phase26;

public sealed class PlayerTransferClient : MonoBehaviour
{
    public bool IsTransferring { get; private set; }
    public string CurrentNodeId { get; private set; }

    public void BeginTransfer(string targetNodeId)
    {
        IsTransferring=true;
        CurrentNodeId=targetNodeId;
    }

    public void ApplyTransferSnapshot(Vector3 position)
    {
        transform.position=position;
        IsTransferring=false;
    }

    public void RejectTransfer()
    {
        IsTransferring=false;
    }
}
