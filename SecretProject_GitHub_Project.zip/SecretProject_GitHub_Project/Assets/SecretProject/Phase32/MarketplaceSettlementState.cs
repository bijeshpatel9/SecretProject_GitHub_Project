namespace SecretProject.Phase32.Unity;
public sealed class MarketplaceSettlementState {
 public bool WaitingForSettlement{get;private set;}
 public long LastSettlementVersion{get;private set;}
 public void Begin()=>WaitingForSettlement=true;
 public void ApplyAuthoritativeSettlement(long version){if(version<LastSettlementVersion)return;LastSettlementVersion=version;WaitingForSettlement=false;}
 public void Fail()=>WaitingForSettlement=false;
}
