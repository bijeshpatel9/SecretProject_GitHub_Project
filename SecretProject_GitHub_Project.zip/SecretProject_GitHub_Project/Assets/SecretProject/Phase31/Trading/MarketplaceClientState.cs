using System;
using System.Collections.Generic;
using SecretProject.Contracts.Trading;

namespace SecretProject.Unity.Trading
{
    public sealed class MarketplaceClientState
    {
        private readonly Dictionary<Guid, MarketplaceListing> _listings = new();
        public IReadOnlyCollection<MarketplaceListing> Listings => _listings.Values;

        public void ApplySnapshot(IEnumerable<MarketplaceListing> snapshot)
        {
            _listings.Clear();
            foreach (var listing in snapshot) _listings[listing.ListingId]=listing;
        }

        public void Upsert(MarketplaceListing listing)
        {
            if (_listings.TryGetValue(listing.ListingId,out var current) &&
                current.Version >= listing.Version) return;
            _listings[listing.ListingId]=listing;
        }

        public bool Remove(Guid listingId) => _listings.Remove(listingId);
    }
}