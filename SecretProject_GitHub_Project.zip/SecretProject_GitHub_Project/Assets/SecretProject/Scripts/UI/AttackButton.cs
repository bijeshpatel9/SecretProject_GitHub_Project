using UnityEngine;
using SecretProject.Combat;

namespace SecretProject.UI
{
    public class AttackButton : MonoBehaviour
    {
        [SerializeField] private PlayerAttack playerAttack;

        public void PressAttack()
        {
            if (playerAttack)
                playerAttack.Attack();
        }
    }
}
