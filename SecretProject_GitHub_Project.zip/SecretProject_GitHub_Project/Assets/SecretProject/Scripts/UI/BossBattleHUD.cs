using UnityEngine;
using UnityEngine.UI;
using TMPro;
using SecretProject.Combat;

namespace SecretProject.UI
{
    public class BossBattleHUD : MonoBehaviour
    {
        [SerializeField] private Health bossHealth;
        [SerializeField] private Health playerHealth;
        [SerializeField] private Slider bossBar;
        [SerializeField] private Slider playerBar;
        [SerializeField] private TMP_Text bossNameText;
        [SerializeField] private TMP_Text phaseText;
        [SerializeField] private TMP_Text alertText;
        [SerializeField] private TMP_Text rewardText;

        public void RefreshBoss()
        {
            if (!bossHealth) return;
            if (bossBar)
            {
                bossBar.maxValue = bossHealth.MaxHealth;
                bossBar.value = bossHealth.CurrentHealth;
            }
        }

        public void RefreshPlayer()
        {
            if (!playerHealth || !playerBar) return;
            playerBar.maxValue = playerHealth.MaxHealth;
            playerBar.value = playerHealth.CurrentHealth;
        }

        public void SetBossName(string value)
        {
            if (bossNameText) bossNameText.text = value;
        }

        public void SetPhase(int phase)
        {
            if (phaseText) phaseText.text = "PHASE " + phase;
        }

        public void ShowAlert(string value)
        {
            if (alertText) alertText.text = value;
        }

        public void ShowReward(string value)
        {
            if (rewardText) rewardText.text = value;
        }
    }
}
