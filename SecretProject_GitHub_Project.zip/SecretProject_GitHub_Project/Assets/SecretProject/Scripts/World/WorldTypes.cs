namespace SecretProject.World
{
    public enum BiomeType { Forest, Meadow, Mountains, Ruins, Swamp, Desert }
    public enum POIType { Village, Cave, Ruins, Treasure, EnemyCamp, Shrine, Resource }
}
