using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.World
{
    public class ProceduralWorldGenerator : MonoBehaviour
    {
        [Header("World")]
        [SerializeField] private WorldSeed worldSeed;
        [SerializeField] private Transform player;
        [SerializeField] private int chunkSize = 40;
        [SerializeField] private int viewDistance = 2;

        [Header("Optional prefabs")]
        [SerializeField] private GameObject[] biomePrefabs;
        [SerializeField] private GameObject[] pointOfInterestPrefabs;

        private readonly Dictionary<Vector2Int, WorldChunk> loaded = new();

        private void Start()
        {
            if (!worldSeed) worldSeed = GetComponent<WorldSeed>();
            GenerateAroundPlayer();
        }

        private void Update()
        {
            GenerateAroundPlayer();
            UnloadFarChunks();
        }

        private Vector2Int PlayerChunk()
        {
            Vector3 p = player ? player.position : transform.position;
            return new Vector2Int(
                Mathf.FloorToInt(p.x / chunkSize),
                Mathf.FloorToInt(p.z / chunkSize)
            );
        }

        private void GenerateAroundPlayer()
        {
            Vector2Int center = PlayerChunk();

            for (int x = -viewDistance; x <= viewDistance; x++)
            for (int z = -viewDistance; z <= viewDistance; z++)
            {
                Vector2Int c = center + new Vector2Int(x, z);
                if (!loaded.ContainsKey(c))
                    GenerateChunk(c);
            }
        }

        private void GenerateChunk(Vector2Int coord)
        {
            GameObject go = new GameObject();
            go.transform.SetParent(transform);
            go.transform.position = new Vector3(coord.x * chunkSize, 0, coord.y * chunkSize);

            WorldChunk chunk = go.AddComponent<WorldChunk>();
            chunk.Initialize(coord);
            loaded.Add(coord, chunk);

            var rng = worldSeed.CreateRandom(coord.x, coord.y);
            BiomeType biome = (BiomeType)rng.Next(System.Enum.GetValues(typeof(BiomeType)).Length);

            int poiCount = rng.Next(1, 4);
            for (int i = 0; i < poiCount; i++)
            {
                SpawnPOI(go.transform, coord, biome, rng, i);
            }

            // Hook for future terrain/vegetation/monster generation.
            if (biomePrefabs != null && biomePrefabs.Length > 0)
            {
                GameObject prefab = biomePrefabs[rng.Next(biomePrefabs.Length)];
                if (prefab) Instantiate(prefab, go.transform.position, Quaternion.identity, go.transform);
            }
        }

        private void SpawnPOI(Transform parent, Vector2Int coord, BiomeType biome, System.Random rng, int index)
        {
            if (pointOfInterestPrefabs == null || pointOfInterestPrefabs.Length == 0) return;

            GameObject prefab = pointOfInterestPrefabs[rng.Next(pointOfInterestPrefabs.Length)];
            if (!prefab) return;

            float offsetX = (float)rng.NextDouble() * chunkSize - chunkSize * 0.5f;
            float offsetZ = (float)rng.NextDouble() * chunkSize - chunkSize * 0.5f;

            Vector3 pos = parent.position + new Vector3(offsetX, 0, offsetZ);
            Instantiate(prefab, pos, Quaternion.Euler(0, rng.Next(0, 360), 0), parent);
        }

        private void UnloadFarChunks()
        {
            Vector2Int center = PlayerChunk();
            List<Vector2Int> remove = new();

            foreach (var pair in loaded)
            {
                int dx = Mathf.Abs(pair.Key.x - center.x);
                int dz = Mathf.Abs(pair.Key.y - center.y);

                if (dx > viewDistance + 1 || dz > viewDistance + 1)
                    remove.Add(pair.Key);
            }

            foreach (Vector2Int c in remove)
            {
                Destroy(loaded[c].gameObject);
                loaded.Remove(c);
            }
        }
    }
}
