using UnityEngine;

namespace SecretProject.World
{
    public class ExplorationEventGenerator : MonoBehaviour
    {
        [SerializeField] private GameObject[] eventPrefabs;

        public void GenerateEvent(Vector3 position, int seed)
        {
            if (eventPrefabs == null || eventPrefabs.Length == 0) return;

            var rng = new System.Random(seed);
            GameObject prefab = eventPrefabs[rng.Next(eventPrefabs.Length)];
            if (prefab)
                Instantiate(prefab, position, Quaternion.identity);
        }
    }
}
