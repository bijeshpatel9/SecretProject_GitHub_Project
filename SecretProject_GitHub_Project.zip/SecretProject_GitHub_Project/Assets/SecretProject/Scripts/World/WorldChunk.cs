using UnityEngine;

namespace SecretProject.World
{
    public class WorldChunk : MonoBehaviour
    {
        public Vector2Int Coordinate { get; private set; }
        public bool Discovered { get; private set; }

        public void Initialize(Vector2Int coordinate)
        {
            Coordinate = coordinate;
            gameObject.name = $"Chunk_{coordinate.x}_{coordinate.y}";
        }

        public void MarkDiscovered() => Discovered = true;
    }
}
