using UnityEngine;

namespace SecretProject.World
{
    [System.Serializable]
    public class GeneratedQuest
    {
        public string title;
        public string objective;
        public int rewardGold;
        public int rewardXP;
    }

    public class DynamicQuestGenerator : MonoBehaviour
    {
        private static readonly string[] locations =
        {
            "the Whispering Forest", "an ancient ruin", "the Moonlit Cave",
            "the Forgotten Shrine", "the wandering village"
        };

        private static readonly string[] objectives =
        {
            "Defeat monsters", "Find a hidden treasure", "Rescue an NPC",
            "Collect rare resources", "Defeat a mini-boss"
        };

        public GeneratedQuest Generate(int seed)
        {
            var rng = new System.Random(seed);
            string objective = objectives[rng.Next(objectives.Length)];
            string location = locations[rng.Next(locations.Length)];

            return new GeneratedQuest
            {
                title = $"{objective} at {location}",
                objective = $"{objective} near {location}.",
                rewardGold = rng.Next(50, 251),
                rewardXP = rng.Next(100, 501)
            };
        }
    }
}
