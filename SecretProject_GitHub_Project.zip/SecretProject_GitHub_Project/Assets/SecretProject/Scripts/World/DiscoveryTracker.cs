using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.World
{
    public class DiscoveryTracker : MonoBehaviour
    {
        private readonly HashSet<string> discovered = new();

        public bool IsDiscovered(Vector2Int coordinate) =>
            discovered.Contains(Key(coordinate));

        public void Discover(Vector2Int coordinate) =>
            discovered.Add(Key(coordinate));

        private string Key(Vector2Int c) => $"{c.x}:{c.y}";
    }
}
