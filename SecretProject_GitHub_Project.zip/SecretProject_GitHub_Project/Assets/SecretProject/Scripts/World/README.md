# Secret Project — Phase 2: Procedural Exploration

This phase adds the foundation for an automatically generated exploration world.

## Included
- Seed-based deterministic chunk generation
- Load/unload chunks around the player
- Random biome selection
- Random points of interest
- Exploration event hook
- Discovery tracking foundation
- Dynamic quest generator

## Unity setup
1. Copy this `Assets/SecretProject` folder into the Phase 1 Unity project.
2. Create an empty `WorldManager` GameObject.
3. Add `WorldSeed` and `ProceduralWorldGenerator`.
4. Assign the Player Transform.
5. Optionally assign biome and POI prefabs.
6. Add `DynamicQuestGenerator` to a quest manager object.

## Important
This is the procedural-system foundation, not final AAA terrain generation. Next, terrain/vegetation/monster spawning, save/load of discovered chunks, and network synchronization should be added before calling it a full MMO world.
