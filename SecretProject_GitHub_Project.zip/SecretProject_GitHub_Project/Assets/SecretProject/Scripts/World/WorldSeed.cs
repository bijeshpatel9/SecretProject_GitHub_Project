using UnityEngine;

namespace SecretProject.World
{
    public class WorldSeed : MonoBehaviour
    {
        [SerializeField] private int seed = 0;
        public int Seed => seed;

        private void Awake()
        {
            if (seed == 0)
                seed = Random.Range(1, int.MaxValue);
        }

        public System.Random CreateRandom(int chunkX, int chunkZ)
        {
            unchecked
            {
                int mixed = seed;
                mixed = mixed * 31 + chunkX;
                mixed = mixed * 31 + chunkZ;
                return new System.Random(mixed);
            }
        }
    }
}
