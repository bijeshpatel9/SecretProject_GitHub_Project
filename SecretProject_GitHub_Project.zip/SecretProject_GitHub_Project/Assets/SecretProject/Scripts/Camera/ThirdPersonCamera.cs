using UnityEngine;

namespace SecretProject.CameraSystem
{
    public class ThirdPersonCamera : MonoBehaviour
    {
        [SerializeField] private Transform target;
        [SerializeField] private float distance = 5f;
        [SerializeField] private float height = 2.2f;
        [SerializeField] private float followSmooth = 12f;
        [SerializeField] private float rotationSmooth = 12f;
        [SerializeField] private float minPitch = -20f;
        [SerializeField] private float maxPitch = 65f;

        private float yaw = 0f;
        private float pitch = 15f;

        public void SetTarget(Transform newTarget) => target = newTarget;

        public void AddLookInput(Vector2 delta)
        {
            yaw += delta.x;
            pitch = Mathf.Clamp(pitch - delta.y, minPitch, maxPitch);
        }

        private void LateUpdate()
        {
            if (!target) return;

            Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 desiredPosition =
                target.position + Vector3.up * height - rotation * Vector3.forward * distance;

            transform.position = Vector3.Lerp(
                transform.position,
                desiredPosition,
                followSmooth * Time.deltaTime
            );

            Quaternion desiredRotation = Quaternion.LookRotation(
                target.position + Vector3.up * height * 0.7f - transform.position
            );

            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                desiredRotation,
                rotationSmooth * Time.deltaTime
            );
        }
    }
}
