using UnityEngine;

namespace SecretProject.Player
{
    public class MobilePlayerInput : MonoBehaviour
    {
        [SerializeField] private ThirdPersonPlayerController player;
        [SerializeField] private VirtualJoystick joystick;

        private void Update()
        {
            if (player && joystick)
                player.SetMoveInput(joystick.Value);
        }
    }
}
