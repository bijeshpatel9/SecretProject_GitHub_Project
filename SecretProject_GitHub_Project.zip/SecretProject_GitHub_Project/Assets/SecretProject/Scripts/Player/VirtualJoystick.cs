using UnityEngine;
using UnityEngine.EventSystems;

namespace SecretProject.Player
{
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [SerializeField] private RectTransform background;
        [SerializeField] private RectTransform handle;
        [SerializeField] private float handleRange = 60f;

        public Vector2 Value { get; private set; }

        public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);

        public void OnDrag(PointerEventData eventData)
        {
            if (!background) return;

            Vector2 localPoint;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                background,
                eventData.position,
                eventData.pressEventCamera,
                out localPoint
            );

            Vector2 size = background.rect.size;
            Value = new Vector2(
                localPoint.x / (size.x * 0.5f),
                localPoint.y / (size.y * 0.5f)
            );
            Value = Vector2.ClampMagnitude(Value, 1f);

            if (handle)
                handle.anchoredPosition = Value * handleRange;
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            Value = Vector2.zero;
            if (handle) handle.anchoredPosition = Vector2.zero;
        }
    }
}
