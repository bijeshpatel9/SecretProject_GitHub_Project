using UnityEngine;

namespace SecretProject.Combat
{
    public class PlayerAttack : MonoBehaviour
    {
        [SerializeField] private Transform attackOrigin;
        [SerializeField] private float attackRange = 2.2f;
        [SerializeField] private int damage = 20;
        [SerializeField] private LayerMask enemyLayers;
        [SerializeField] private float cooldown = 0.6f;

        private float nextAttackTime;

        public void Attack()
        {
            if (Time.time < nextAttackTime) return;
            nextAttackTime = Time.time + cooldown;

            Vector3 origin = attackOrigin ? attackOrigin.position : transform.position + transform.forward;
            Collider[] hits = Physics.OverlapSphere(origin, attackRange, enemyLayers);

            foreach (Collider hit in hits)
            {
                Health health = hit.GetComponentInParent<Health>();
                if (health)
                    health.TakeDamage(damage);
            }
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.DrawWireSphere(
                attackOrigin ? attackOrigin.position : transform.position + transform.forward,
                attackRange
            );
        }
    }
}
