using UnityEngine;
using UnityEngine.Events;

namespace SecretProject.Combat
{
    public class Health : MonoBehaviour
    {
        [SerializeField] private int maxHealth = 100;
        public int MaxHealth => maxHealth;
        public int CurrentHealth { get; private set; }
        public float Normalized => maxHealth <= 0 ? 0f : (float)CurrentHealth / maxHealth;
        public UnityEvent OnDied;
        public UnityEvent<int, int> OnHealthChanged;

        private bool dead;

        private void Awake()
        {
            CurrentHealth = maxHealth;
            OnHealthChanged?.Invoke(CurrentHealth, maxHealth);
        }

        public void SetMaxHealth(int value, bool refill = true)
        {
            maxHealth = Mathf.Max(1, value);
            if (refill) CurrentHealth = maxHealth;
            OnHealthChanged?.Invoke(CurrentHealth, maxHealth);
        }

        public void TakeDamage(int damage)
        {
            if (dead) return;
            damage = Mathf.Max(0, damage);
            CurrentHealth = Mathf.Max(0, CurrentHealth - damage);
            OnHealthChanged?.Invoke(CurrentHealth, maxHealth);

            if (CurrentHealth == 0)
            {
                dead = true;
                OnDied?.Invoke();
            }
        }

        public void Heal(int amount)
        {
            if (dead) return;
            CurrentHealth = Mathf.Min(maxHealth, CurrentHealth + Mathf.Max(0, amount));
            OnHealthChanged?.Invoke(CurrentHealth, maxHealth);
        }
    }
}
