namespace SecretProject.Boss
{
    public static class Phase6BossPresets
    {
        public static readonly string[] CoreMechanics =
        {
            "Abyssal Dragon: expanding void rings + pull",
            "Moon Reaper: delayed moonfall zones",
            "Eternal Frost Queen: freeze fields",
            "Crimson Oni King: bleed + dash combo",
            "Storm Sovereign: lightning line chains",
            "World Eater: swallow zones + summons",
            "Phantom Emperor: false telegraphs + soul traps",
            "Celestial Valkyrie: aerial judgment markers",
            "Inferno Titan: lava zones + charge",
            "Abyss Knight: dimension dash",
            "Sea Leviathan: tidal waves",
            "Forest Ancient: root traps + adds",
            "Time Warden: slow zones + time burst",
            "Fallen Seraph: falling holy strikes",
            "??? The Unknown One: adaptive pattern"
        };
    }
}
