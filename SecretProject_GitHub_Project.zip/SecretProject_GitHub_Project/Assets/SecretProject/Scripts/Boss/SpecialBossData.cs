using UnityEngine;

namespace SecretProject.Boss
{
    [CreateAssetMenu(menuName = "Secret Project/Special Boss Data")]
    public class SpecialBossData : ScriptableObject
    {
        public int bossId;
        public string bossName;
        [TextArea] public string description;
        public string ssPlusSkillName;
        public int recommendedLevel = 50;
        public GameObject bossPrefab;
        public GameObject skillRewardPrefab;
    }
}
