using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.Boss
{
    public class SSPlusSkillUnlocker : MonoBehaviour
    {
        private readonly HashSet<int> unlocked = new();
        private const string Prefix = "SecretProject_SSPlusSkill_";

        public bool IsUnlocked(int bossId) =>
            unlocked.Contains(bossId) || PlayerPrefs.GetInt(Prefix + bossId, 0) == 1;

        public void Unlock(int bossId, string skillName)
        {
            if (IsUnlocked(bossId)) return;

            unlocked.Add(bossId);
            PlayerPrefs.SetInt(Prefix + bossId, 1);
            PlayerPrefs.Save();

            Debug.Log($"SS+ Skill Unlocked: {skillName}");
        }
    }
}
