using UnityEngine;
using SecretProject.Combat;

namespace SecretProject.Boss
{
    public enum BossStatusEffect { Burn, Freeze, Bleed, Slow, Silence }

    public class BossStatusEffects : MonoBehaviour
    {
        public void Apply(GameObject target, BossStatusEffect effect, float duration, int tickDamage)
        {
            if (!target) return;
            target.SendMessage("OnBossStatusApplied", effect, SendMessageOptions.DontRequireReceiver);
            if (tickDamage > 0)
                target.GetComponentInParent<Health>()?.TakeDamage(tickDamage);
        }
    }
}
