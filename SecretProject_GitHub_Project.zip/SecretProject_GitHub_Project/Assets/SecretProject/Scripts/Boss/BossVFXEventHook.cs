using UnityEngine;
namespace SecretProject.Boss {
public class BossVFXEventHook:MonoBehaviour {
[SerializeField] ParticleSystem phaseVFX,attackVFX,specialVFX,deathVFX;
public void OnBossPhaseChanged(int p){if(phaseVFX)phaseVFX.Play();}
public void OnBossAttack(){if(attackVFX)attackVFX.Play();}
public void OnSpecialAbilityUsed(int p){if(specialVFX)specialVFX.Play();}
public void OnBossDefeated(){if(deathVFX)deathVFX.Play();}
}}