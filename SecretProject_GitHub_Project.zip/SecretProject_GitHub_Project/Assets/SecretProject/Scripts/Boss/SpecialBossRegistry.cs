using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.Boss
{
    public class SpecialBossRegistry : MonoBehaviour
    {
        [SerializeField] private SpecialBossData[] bosses;

        private readonly HashSet<int> defeated = new();
        private const string Prefix = "SecretProject_BossDefeated_";

        private void Awake()
        {
            LoadDefeated();
        }

        public bool IsDefeated(int bossId) => defeated.Contains(bossId);

        public bool TryDefeat(int bossId)
        {
            if (IsDefeated(bossId)) return false;

            defeated.Add(bossId);
            PlayerPrefs.SetInt(Prefix + bossId, 1);
            PlayerPrefs.Save();
            return true;
        }

        public SpecialBossData GetBoss(int bossId)
        {
            foreach (var boss in bosses)
                if (boss && boss.bossId == bossId)
                    return boss;
            return null;
        }

        private void LoadDefeated()
        {
            if (bosses == null) return;
            foreach (var boss in bosses)
            {
                if (boss && PlayerPrefs.GetInt(Prefix + boss.bossId, 0) == 1)
                    defeated.Add(boss.bossId);
            }
        }
    }
}
