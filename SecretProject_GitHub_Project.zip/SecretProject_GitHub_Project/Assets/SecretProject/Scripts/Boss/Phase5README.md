# Secret Project — Phase 5 COMPLETE

Phase 5 is the complete prototype encounter layer.

## Included
- Three-phase boss progression
- Enrage at 15% HP
- Boss chase/contact combat
- Ability telegraphs before damage
- Target-following and area abilities
- Knockback support
- Phase-driven ability selection
- Enrage VFX hook
- Boss battle HUD hooks
- One-time prototype reward persistence
- 15-boss signature ability catalog
- Bootstrap component for a playable encounter

## Suggested playable scene
Create a scene named `Phase5_BossBattle_Test`.

Scene objects:
1. `Arena`
   - Large Plane
   - Walls / barriers
   - Optional fire, rune and fog VFX
2. `Player`
   - Tag: Player
   - Health
   - Existing Phase 1 third-person controller/camera
3. `CrimsonOniKing`
   - Health (45,000)
   - BossCombatController
   - BossPhaseController
   - BossUniqueMechanics
   - BossEnrageEffects
   - BossRewardController
4. `HUD`
   - Canvas
   - Boss Slider
   - Player Slider
   - Boss name
   - Phase text
   - Alert/reward text
   - Existing mobile joystick and skill buttons
5. `Phase5Bootstrap`
   - Assign boss prefab and spawn point.

## Phase thresholds
Phase 1: 100% -> 70%
Phase 2: 70% -> 40%
Phase 3: 40% -> 15%
Enrage: 15% -> 0%

## Important
PlayerPrefs is only a local prototype persistence mechanism. In the final MMO,
boss damage, phases, defeat state, reward ownership, SS+ skill unlock and
anti-cheat validation must be authoritative on the multiplayer server.

## Integration
This package is designed to sit on top of the earlier Secret Project phases.
It does not replace the procedural world or existing player/camera systems.
