using UnityEngine;

namespace SecretProject.Boss
{
    public class SpecialBossSpawner : MonoBehaviour
    {
        [SerializeField] private SpecialBossRegistry registry;
        [SerializeField] private int bossId;
        [SerializeField] private Transform spawnPoint;

        private GameObject spawnedBoss;

        private void Start()
        {
            if (!registry) registry = FindFirstObjectByType<SpecialBossRegistry>();
            TrySpawn();
        }

        public void TrySpawn()
        {
            if (!registry || registry.IsDefeated(bossId)) return;

            SpecialBossData data = registry.GetBoss(bossId);
            if (!data || !data.bossPrefab) return;

            Transform point = spawnPoint ? spawnPoint : transform;
            spawnedBoss = Instantiate(data.bossPrefab, point.position, point.rotation);
            SpecialBossInstance instance = spawnedBoss.GetComponent<SpecialBossInstance>();

            if (!instance)
                instance = spawnedBoss.AddComponent<SpecialBossInstance>();

            instance.Initialize(registry, data);
        }
    }
}
