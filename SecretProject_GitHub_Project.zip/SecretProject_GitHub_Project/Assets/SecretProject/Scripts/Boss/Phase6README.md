# Secret Project — Phase 6: Advanced Boss Mechanics

Adds:
- Pattern assets: cone, line, ring, meteor, dash, summon
- Telegraph/dodge windows
- Recovery windows
- Phase-based pattern selection
- Status-effect hooks
- Boss summons
- Pattern VFX hooks
- 15-boss mechanic design presets

Suggested encounter loop:
Telegraph -> Dodge Window -> Attack -> Recovery -> Next Pattern.

Important:
This is prototype gameplay logic. In the final MMO, hit validation,
cooldowns, boss AI state, status effects, summons and rewards must be
server-authoritative.
