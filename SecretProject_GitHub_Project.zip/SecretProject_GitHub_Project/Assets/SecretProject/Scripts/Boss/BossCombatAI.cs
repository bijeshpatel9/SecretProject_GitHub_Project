using UnityEngine;
using SecretProject.Combat;
namespace SecretProject.Boss {
[RequireComponent(typeof(Health))]
public class BossCombatAI:MonoBehaviour {
[SerializeField] Transform target; [SerializeField] float detectionRange=25f,attackRange=3f,moveSpeed=3.5f,attackCooldown=1.5f; [SerializeField] int attackDamage=15; float nextAttack; Health health;
void Awake(){health=GetComponent<Health>();}
void Update(){if(health.CurrentHealth<=0)return;if(!target){var p=GameObject.FindGameObjectWithTag("Player");if(p)target=p.transform;}if(!target)return;var d=target.position-transform.position;d.y=0;if(d.magnitude>detectionRange)return;if(d.sqrMagnitude>.01f)transform.rotation=Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(d.normalized),8f*Time.deltaTime);if(d.magnitude>attackRange)transform.position+=d.normalized*moveSpeed*Time.deltaTime;else if(Time.time>=nextAttack){nextAttack=Time.time+attackCooldown;var h=target.GetComponentInParent<Health>();if(h)h.TakeDamage(attackDamage);SendMessage("OnBossAttack",SendMessageOptions.DontRequireReceiver);}}
}}