using UnityEngine;
using SecretProject.Combat;

namespace SecretProject.Boss
{
    [RequireComponent(typeof(Health))]
    public class BossCombatController : MonoBehaviour
    {
        [SerializeField] private float detectionRange = 30f;
        [SerializeField] private float attackRange = 3f;
        [SerializeField] private float moveSpeed = 3f;
        [SerializeField] private float attackCooldown = 1.4f;
        [SerializeField] private int contactDamage = 30;

        private Transform target;
        private Health health;
        private float nextAttack;

        private void Awake() => health = GetComponent<Health>();

        private void Update()
        {
            if (!health || health.CurrentHealth <= 0) return;

            if (!target)
            {
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player) target = player.transform;
            }

            if (!target) return;

            Vector3 delta = target.position - transform.position;
            delta.y = 0f;
            float distance = delta.magnitude;

            if (distance > detectionRange) return;

            if (delta.sqrMagnitude > 0.01f)
                transform.rotation = Quaternion.Slerp(
                    transform.rotation,
                    Quaternion.LookRotation(delta.normalized),
                    8f * Time.deltaTime
                );

            if (distance > attackRange)
                transform.position += delta.normalized * moveSpeed * Time.deltaTime;
            else if (Time.time >= nextAttack)
            {
                nextAttack = Time.time + attackCooldown;
                Health playerHealth = target.GetComponentInParent<Health>();
                if (playerHealth) playerHealth.TakeDamage(contactDamage);
                SendMessage("OnBossAttack", SendMessageOptions.DontRequireReceiver);
            }
        }
    }
}
