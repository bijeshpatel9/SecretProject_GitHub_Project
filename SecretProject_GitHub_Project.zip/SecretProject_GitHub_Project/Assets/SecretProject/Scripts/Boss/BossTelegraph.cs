using UnityEngine;

namespace SecretProject.Boss
{
    public class BossTelegraph : MonoBehaviour
    {
        [SerializeField] private GameObject warningPrefab;
        [SerializeField] private float yOffset = 0.03f;

        private GameObject activeWarning;

        public void Show(Vector3 center, float radius, float duration)
        {
            Hide();
            if (!warningPrefab) return;

            activeWarning = Instantiate(
                warningPrefab,
                new Vector3(center.x, center.y + yOffset, center.z),
                Quaternion.identity
            );
            activeWarning.transform.localScale = Vector3.one * radius * 2f;
            Destroy(activeWarning, duration);
        }

        public void Hide()
        {
            if (activeWarning) Destroy(activeWarning);
            activeWarning = null;
        }
    }
}
