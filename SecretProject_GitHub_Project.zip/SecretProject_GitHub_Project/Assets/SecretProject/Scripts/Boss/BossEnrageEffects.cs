using UnityEngine;

namespace SecretProject.Boss
{
    public class BossEnrageEffects : MonoBehaviour
    {
        [SerializeField] private ParticleSystem enrageVFX;
        [SerializeField] private float enrageSpeedMultiplier = 1.35f;

        public void OnBossEnraged()
        {
            if (enrageVFX) enrageVFX.Play();
            transform.localScale *= 1.05f;
            SendMessage("OnEnrageSpeedMultiplier", enrageSpeedMultiplier, SendMessageOptions.DontRequireReceiver);
        }
    }
}
