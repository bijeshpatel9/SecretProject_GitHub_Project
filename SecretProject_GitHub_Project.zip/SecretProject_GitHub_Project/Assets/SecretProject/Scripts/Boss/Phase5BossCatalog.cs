namespace SecretProject.Boss
{
    public static class Phase5BossCatalog
    {
        public static readonly string[] Bosses =
        {
            "Abyssal Dragon",
            "Moon Reaper",
            "Eternal Frost Queen",
            "Crimson Oni King",
            "Storm Sovereign",
            "World Eater",
            "Phantom Emperor",
            "Celestial Valkyrie",
            "Inferno Titan",
            "Abyss Knight",
            "Sea Leviathan",
            "Forest Ancient",
            "Time Warden",
            "Fallen Seraph",
            "??? The Unknown One"
        };

        public static readonly string[] SignatureSkills =
        {
            "Void Devour", "Moonfall", "Absolute Zero", "Blood Dominion",
            "Heavenly Ruin", "Devourer", "Soul Sever", "Divine Judgment",
            "Apocalypse Flame", "Dimension Slash", "Tidal Cataclysm", "Worldroot",
            "Time Break", "Heaven's Fall", "???"
        };
    }
}
