using UnityEngine;

namespace SecretProject.Boss
{
    public class BossDodgeWindow : MonoBehaviour
    {
        public bool IsActive { get; private set; }
        public float Remaining { get; private set; }

        public void Open(float duration)
        {
            IsActive = true;
            Remaining = duration;
        }

        private void Update()
        {
            if (!IsActive) return;
            Remaining -= Time.deltaTime;
            if (Remaining <= 0f)
            {
                Remaining = 0f;
                IsActive = false;
            }
        }
    }
}
