using UnityEngine;

namespace SecretProject.Boss
{
    public enum BossPatternType { Cone, Line, Ring, Meteor, Dash, Summon }

    [CreateAssetMenu(menuName="Secret Project/Boss Attack Pattern")]
    public class BossAttackPattern : ScriptableObject
    {
        public BossPatternType pattern = BossPatternType.Cone;
        public string patternName = "Boss Attack";
        public int damage = 150;
        public float radius = 5f;
        public float telegraphTime = 1.2f;
        public float recoveryTime = 1f;
        public float cooldown = 6f;
        public float dashDistance = 10f;
        public int projectileCount = 6;
    }
}
