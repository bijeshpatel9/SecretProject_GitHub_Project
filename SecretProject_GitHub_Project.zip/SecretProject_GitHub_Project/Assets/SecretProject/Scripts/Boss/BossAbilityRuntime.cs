using UnityEngine;

namespace SecretProject.Boss
{
    public class BossAbilityRuntime
    {
        public BossAbilityDefinition Definition;
        public float ReadyAt;

        public BossAbilityRuntime(BossAbilityDefinition definition)
        {
            Definition = definition;
            ReadyAt = 0f;
        }
    }
}
