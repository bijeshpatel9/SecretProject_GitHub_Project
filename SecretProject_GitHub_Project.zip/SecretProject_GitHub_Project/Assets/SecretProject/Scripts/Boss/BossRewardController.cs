using UnityEngine;
using SecretProject.Combat;

namespace SecretProject.Boss
{
    public class BossRewardController : MonoBehaviour
    {
        [SerializeField] private int bossId = 1;
        [SerializeField] private string skillName = "SS+ Skill";
        [SerializeField] private string rewardMessage = "SS+ SKILL UNLOCKED!";

        private Health health;
        private bool rewarded;

        private void Awake()
        {
            health = GetComponent<Health>();
            if (health) health.OnDied.AddListener(Reward);
        }

        private void Reward()
        {
            if (rewarded) return;
            rewarded = true;

            PlayerPrefs.SetInt("BossDefeated_" + bossId, 1);
            PlayerPrefs.SetString("SSPlusSkill_" + bossId, skillName);
            PlayerPrefs.Save();

            Debug.Log(rewardMessage + "  " + skillName);
            SendMessage("OnSSPlusReward", skillName, SendMessageOptions.DontRequireReceiver);
        }
    }
}
