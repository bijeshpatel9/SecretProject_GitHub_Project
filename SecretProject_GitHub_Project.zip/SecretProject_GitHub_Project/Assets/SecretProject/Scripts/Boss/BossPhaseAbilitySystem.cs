using UnityEngine;
using SecretProject.Combat;
namespace SecretProject.Boss {
public class BossPhaseAbilitySystem:MonoBehaviour {
[System.Serializable] public class Ability{public float cooldown=8f,range=6f;public int damage=35;}
[SerializeField] Ability[] abilities; int phase; float next;
public void OnBossPhaseChanged(int p){phase=Mathf.Clamp(p,0,abilities.Length-1);next=Time.time+1;}
void Update(){if(abilities==null||abilities.Length==0||Time.time<next)return;var a=abilities[phase];next=Time.time+a.cooldown;foreach(var c in Physics.OverlapSphere(transform.position,a.range))if(c.CompareTag("Player")){var h=c.GetComponentInParent<Health>();if(h)h.TakeDamage(a.damage);}SendMessage("OnSpecialAbilityUsed",phase,SendMessageOptions.DontRequireReceiver);}
}}