using UnityEngine;
using SecretProject.Combat;

namespace SecretProject.Boss
{
    public class SpecialBossInstance : MonoBehaviour
    {
        private SpecialBossRegistry registry;
        private SpecialBossData data;
        private bool processed;

        public void Initialize(SpecialBossRegistry bossRegistry, SpecialBossData bossData)
        {
            registry = bossRegistry;
            data = bossData;

            Health health = GetComponent<Health>();
            if (!health) health = gameObject.AddComponent<Health>();
            health.OnDied.AddListener(OnBossDefeated);
        }

        private void OnBossDefeated()
        {
            if (processed || !registry || !data) return;
            processed = true;

            if (!registry.TryDefeat(data.bossId))
                return;

            SSPlusSkillUnlocker unlocker = FindFirstObjectByType<SSPlusSkillUnlocker>();
            if (unlocker)
                unlocker.Unlock(data.bossId, data.ssPlusSkillName);
        }
    }
}
