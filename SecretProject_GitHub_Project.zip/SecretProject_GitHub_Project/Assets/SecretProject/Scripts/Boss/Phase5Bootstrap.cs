using UnityEngine;
using SecretProject.Combat;
using SecretProject.UI;

namespace SecretProject.Boss
{
    public class Phase5Bootstrap : MonoBehaviour
    {
        [SerializeField] private GameObject bossPrefab;
        [SerializeField] private Transform bossSpawn;
        [SerializeField] private GameObject arenaRoot;
        [SerializeField] private BossBattleHUD hud;
        [SerializeField] private string bossName = "Crimson Oni King";

        private GameObject bossInstance;

        private void Start()
        {
            if (bossPrefab && bossSpawn)
            {
                bossInstance = Instantiate(bossPrefab, bossSpawn.position, bossSpawn.rotation);

                Health bossHealth = bossInstance.GetComponent<Health>();
                if (hud)
                {
                    hud.SetBossName(bossName);
                    hud.ShowAlert("ENTER THE BOSS ARENA");
                }

                if (bossHealth)
                    bossHealth.OnDied.AddListener(OnBossDefeated);

                BossPhaseController phase = bossInstance.GetComponent<BossPhaseController>();
                if (phase)
                    phase.SendMessage("OnBossPhaseChanged", 0, SendMessageOptions.DontRequireReceiver);
            }
        }

        private void OnBossDefeated()
        {
            if (hud) hud.ShowReward("SS+ SKILL UNLOCKED!");
            Debug.Log("Phase 5 encounter complete.");
        }
    }
}
