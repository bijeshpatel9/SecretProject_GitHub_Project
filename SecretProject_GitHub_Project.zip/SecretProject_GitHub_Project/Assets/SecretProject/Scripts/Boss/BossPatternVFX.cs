using UnityEngine;

namespace SecretProject.Boss
{
    public class BossPatternVFX : MonoBehaviour
    {
        [SerializeField] private ParticleSystem telegraphVFX;
        [SerializeField] private ParticleSystem castVFX;
        [SerializeField] private ParticleSystem summonVFX;

        public void OnPatternTelegraph(BossAttackPattern pattern)
        {
            if (telegraphVFX) telegraphVFX.Play();
        }

        public void OnPatternCast(BossAttackPattern pattern)
        {
            if (castVFX) castVFX.Play();
        }

        public void OnBossSummonRequested()
        {
            if (summonVFX) summonVFX.Play();
        }
    }
}
