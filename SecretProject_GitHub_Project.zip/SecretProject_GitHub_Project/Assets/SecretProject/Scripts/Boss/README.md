# Secret Project Phase 4 — Boss Combat
Added: chase AI, normal attacks, health phases, phase abilities, arena barriers and VFX hooks.
For each special boss add Health, BossCombatAI, BossPhaseController, BossPhaseAbilitySystem and BossVFXEventHook.
Player must use tag Player and have Health.
Production MMO version must move boss health, damage, phases, rewards and one-time defeat validation to the authoritative server.
