using System.Collections;
using UnityEngine;
using SecretProject.Combat;

namespace SecretProject.Boss
{
    public class BossAdvancedPatternController : MonoBehaviour
    {
        [SerializeField] private BossAttackPattern[] phasePatterns;
        [SerializeField] private BossDodgeWindow dodgeWindow;
        [SerializeField] private Transform target;

        private int phase;
        private float nextPattern;
        private bool casting;

        public void OnBossPhaseChanged(int newPhase)
        {
            phase = Mathf.Clamp(newPhase, 0, Mathf.Max(0, phasePatterns.Length - 1));
            nextPattern = Time.time + 1.5f;
        }

        private void Update()
        {
            if (casting || phasePatterns == null || phasePatterns.Length == 0) return;
            if (Time.time < nextPattern) return;

            if (!target)
            {
                var player = GameObject.FindGameObjectWithTag("Player");
                if (player) target = player.transform;
            }
            if (target) StartCoroutine(Execute(phasePatterns[phase]));
        }

        private IEnumerator Execute(BossAttackPattern p)
        {
            casting = true;
            Vector3 origin = transform.position;
            Vector3 targetPoint = target ? target.position : origin + transform.forward * 5f;

            if (dodgeWindow) dodgeWindow.Open(p.telegraphTime);

            SendMessage("OnPatternTelegraph", p, SendMessageOptions.DontRequireReceiver);
            yield return new WaitForSeconds(p.telegraphTime);

            switch (p.pattern)
            {
                case BossPatternType.Ring:
                case BossPatternType.Meteor:
                case BossPatternType.Cone:
                    AreaDamage(targetPoint, p);
                    break;
                case BossPatternType.Line:
                    LineDamage(origin, targetPoint, p);
                    break;
                case BossPatternType.Dash:
                    transform.position = Vector3.MoveTowards(transform.position, targetPoint, p.dashDistance);
                    AreaDamage(transform.position, p);
                    break;
                case BossPatternType.Summon:
                    SendMessage("OnBossSummonRequested", SendMessageOptions.DontRequireReceiver);
                    break;
            }

            SendMessage("OnPatternCast", p, SendMessageOptions.DontRequireReceiver);
            yield return new WaitForSeconds(p.recoveryTime);

            nextPattern = Time.time + p.cooldown;
            casting = false;
        }

        private void AreaDamage(Vector3 center, BossAttackPattern p)
        {
            foreach (var c in Physics.OverlapSphere(center, p.radius))
            {
                if (!c.CompareTag("Player")) continue;
                var hp = c.GetComponentInParent<Health>();
                if (hp) hp.TakeDamage(p.damage);
            }
        }

        private void LineDamage(Vector3 a, Vector3 b, BossAttackPattern p)
        {
            Vector3 dir = (b-a).normalized;
            foreach (var c in Physics.OverlapCapsule(a, a + dir * p.radius * 2f, p.radius))
            {
                if (!c.CompareTag("Player")) continue;
                var hp = c.GetComponentInParent<Health>();
                if (hp) hp.TakeDamage(p.damage);
            }
        }
    }
}
