using UnityEngine;
namespace SecretProject.Boss {
public class BossArenaController:MonoBehaviour {
[SerializeField] GameObject entranceBarrier,exitBarrier; bool started;
void OnTriggerEnter(Collider other){if(other.CompareTag("Player")&&!started){started=true;if(entranceBarrier)entranceBarrier.SetActive(true);if(exitBarrier)exitBarrier.SetActive(true);}}
public void EndFight(){if(entranceBarrier)entranceBarrier.SetActive(false);if(exitBarrier)exitBarrier.SetActive(false);}
}}