using UnityEngine;

namespace SecretProject.Boss
{
    public enum BossAbilityType
    {
        VoidDevour, Moonfall, AbsoluteZero, BloodDominion, HeavenlyRuin,
        Devourer, SoulSever, DivineJudgment, ApocalypseFlame, DimensionSlash,
        TidalCataclysm, Worldroot, TimeBreak, HeavensFall, Unknown
    }

    [CreateAssetMenu(menuName = "Secret Project/Boss Ability")]
    public class BossAbilityDefinition : ScriptableObject
    {
        public BossAbilityType type;
        public string abilityName;
        [TextArea] public string description;
        public int damage = 100;
        public float radius = 5f;
        public float cooldown = 8f;
        public float telegraphTime = 1.25f;
        public bool followsTarget;
        public bool knockback;
        public float knockbackForce = 6f;
    }
}
