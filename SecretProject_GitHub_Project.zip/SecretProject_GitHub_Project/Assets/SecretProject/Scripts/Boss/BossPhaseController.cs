using UnityEngine;
using SecretProject.Combat;

namespace SecretProject.Boss
{
    [RequireComponent(typeof(Health))]
    public class BossPhaseController : MonoBehaviour
    {
        [SerializeField] private float phase2At = 0.70f;
        [SerializeField] private float phase3At = 0.40f;
        [SerializeField] private float enrageAt = 0.15f;

        public int CurrentPhase { get; private set; } = 1;
        public bool Enraged { get; private set; }

        private Health health;

        private void Awake()
        {
            health = GetComponent<Health>();
        }

        private void Update()
        {
            if (!health || health.CurrentHealth <= 0) return;

            float hp = health.Normalized;

            if (CurrentPhase == 1 && hp <= phase2At)
                ChangePhase(2);

            if (CurrentPhase == 2 && hp <= phase3At)
                ChangePhase(3);

            if (!Enraged && hp <= enrageAt)
            {
                Enraged = true;
                SendMessage("OnBossEnraged", SendMessageOptions.DontRequireReceiver);
            }
        }

        private void ChangePhase(int value)
        {
            CurrentPhase = value;
            SendMessage("OnBossPhaseChanged", CurrentPhase - 1, SendMessageOptions.DontRequireReceiver);
        }
    }
}
