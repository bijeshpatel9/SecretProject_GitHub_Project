using UnityEngine;
using SecretProject.Combat;

namespace SecretProject.Boss
{
    public class BossUniqueMechanics : MonoBehaviour
    {
        [SerializeField] private BossAbilityDefinition[] phaseAbilities;
        [SerializeField] private BossTelegraph telegraph;
        [SerializeField] private Transform castPoint;

        private Transform target;
        private int phase;
        private float nextCast;
        private bool casting;

        public void SetTarget(Transform value) => target = value;

        public void OnBossPhaseChanged(int newPhase)
        {
            phase = Mathf.Clamp(newPhase, 0, Mathf.Max(0, phaseAbilities.Length - 1));
            nextCast = Time.time + 2f;
        }

        private void Update()
        {
            if (casting || phaseAbilities == null || phaseAbilities.Length == 0) return;
            if (Time.time < nextCast) return;

            if (!target)
            {
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player) target = player.transform;
            }

            if (!target) return;

            BossAbilityDefinition ability = phaseAbilities[phase];
            StartCoroutine(CastRoutine(ability));
        }

        private System.Collections.IEnumerator CastRoutine(BossAbilityDefinition ability)
        {
            casting = true;

            Vector3 center = castPoint ? castPoint.position : transform.position;
            if (ability.followsTarget) center = target.position;

            if (telegraph)
                telegraph.Show(center, ability.radius, ability.telegraphTime);

            SendMessage("OnBossAbilityTelegraph", ability, SendMessageOptions.DontRequireReceiver);

            yield return new WaitForSeconds(ability.telegraphTime);

            if (ability.followsTarget && target)
                center = target.position;

            Collider[] hits = Physics.OverlapSphere(center, ability.radius);

            foreach (Collider hit in hits)
            {
                if (!hit.CompareTag("Player")) continue;

                Health hp = hit.GetComponentInParent<Health>();
                if (hp) hp.TakeDamage(ability.damage);

                if (ability.knockback)
                {
                    Rigidbody rb = hit.GetComponentInParent<Rigidbody>();
                    if (rb)
                    {
                        Vector3 dir = (hit.transform.position - center).normalized;
                        rb.AddForce(dir * ability.knockbackForce, ForceMode.Impulse);
                    }
                }
            }

            SendMessage("OnBossAbilityCast", ability, SendMessageOptions.DontRequireReceiver);

            nextCast = Time.time + ability.cooldown;
            casting = false;
        }
    }
}
