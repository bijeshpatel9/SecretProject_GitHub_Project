using UnityEngine;

namespace SecretProject.Boss
{
    public class BossSummonController : MonoBehaviour
    {
        [SerializeField] private GameObject summonPrefab;
        [SerializeField] private Transform[] spawnPoints;
        [SerializeField] private int maxAlive = 3;

        private int alive;

        public void OnBossSummonRequested()
        {
            if (!summonPrefab || spawnPoints == null || spawnPoints.Length == 0) return;
            if (alive >= maxAlive) return;

            Transform point = spawnPoints[Random.Range(0, spawnPoints.Length)];
            Instantiate(summonPrefab, point.position, point.rotation);
            alive++;
        }

        public void RegisterSummonDeath()
        {
            alive = Mathf.Max(0, alive - 1);
        }
    }
}
