using UnityEngine;

namespace SecretProject.Boss
{
    public class CrimsonOniKingPreset : MonoBehaviour
    {
        [Header("Phase ability names")]
        public string phase1 = "Blood Dominion";
        public string phase2 = "Crimson Meteor";
        public string phase3 = "Oni Massacre";

        [Header("Encounter")]
        public int bossHealth = 45000;
        public int bossId = 4;
        public string ssPlusReward = "Blood Dominion";

        public string GetAbilityForPhase(int phase)
        {
            if (phase <= 1) return phase1;
            if (phase == 2) return phase2;
            return phase3;
        }
    }
}
