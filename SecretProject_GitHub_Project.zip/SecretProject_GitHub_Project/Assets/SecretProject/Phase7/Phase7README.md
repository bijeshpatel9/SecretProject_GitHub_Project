# Secret Project — Phase 7
Player Combat Upgrade

Includes:
- 4-step combo attack
- Dodge/roll with invulnerability hook
- Skill system and cooldowns
- Area skill damage
- Animator hooks
- Mobile-ready public methods

Controls:
Mouse 1 = combo
Space = dodge
1 = Arc Slash
2 = Impact Burst

Add to Player:
CombatStats
PlayerComboController
PlayerDodgeController
PlayerSkillController
PlayerCombatController
Phase7Bootstrap

Final MMO requirement:
Server-authoritative damage, cooldowns, dodge invulnerability,
skill ownership and rewards. Client combat is prototype logic only.

Next: Phase 8 — MMO networking and persistent progression.
