# Secret Project — Phase 18

## Real-Time Server Combat + WebSocket Combat Sync

Phase 18 adds a real-time combat channel on top of Phase 17 server-authoritative hit validation.

Flow:
Unity input -> WebSocket Attack/Skill Intent -> server validation -> server damage -> CombatResult -> Unity presentation.

Client never sends trusted damage or target health.

### Unity
- RealtimeCombatClient.cs
- CombatRealtimeMessage.cs
- RealtimeCombatModels.cs
- RealtimeCombatPresenter.cs
- Phase18Bootstrap.cs

### Server
- WebSocket endpoint `/ws`
- authenticated session hook
- server tick
- attack/skill intent validation
- sequence/replay checks
- cooldown/rate checks
- range/facing/world hooks
- server-computed damage
- combat result broadcast

This is a prototype transport/combat synchronization layer. Production requires WSS/TLS, real session validation, authoritative world/physics, zone/shard routing, interest management, distributed rate limiting, reconnect/resume, and persistent audit telemetry.
