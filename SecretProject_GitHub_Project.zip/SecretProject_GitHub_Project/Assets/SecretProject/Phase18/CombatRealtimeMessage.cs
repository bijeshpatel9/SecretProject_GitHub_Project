using System;
using System.Text.Json.Serialization;

namespace SecretProject.Phase18;

public enum CombatMessageType { Hello, AttackIntent, SkillIntent, CombatResult, StateSnapshot, Ping, Pong, Error }

public sealed class CombatRealtimeMessage
{
    [JsonPropertyName("type")] public CombatMessageType Type { get; set; }
    [JsonPropertyName("sequence")] public long Sequence { get; set; }
    [JsonPropertyName("serverTick")] public long ServerTick { get; set; }
    [JsonPropertyName("payload")] public string Payload { get; set; } = "";
}
