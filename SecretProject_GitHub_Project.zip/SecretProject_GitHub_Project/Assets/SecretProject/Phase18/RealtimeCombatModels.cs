using System;
using System.Numerics;

namespace SecretProject.Phase18;

[Serializable]
public sealed class AttackIntentMessage
{
    public long sequence;
    public string attackId = "basic";
    public string targetId = "";
    public float clientTime;
}

[Serializable]
public sealed class SkillIntentMessage
{
    public long sequence;
    public string skillId = "";
    public string targetId = "";
    public float clientTime;
}

[Serializable]
public sealed class CombatResultMessage
{
    public long sequence;
    public bool accepted;
    public string reason = "";
    public string attackerId = "";
    public string targetId = "";
    public int damage;
    public int targetHealth;
    public long serverTick;
}
