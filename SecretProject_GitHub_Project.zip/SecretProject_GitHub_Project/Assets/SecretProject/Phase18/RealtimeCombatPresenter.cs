using UnityEngine;

namespace SecretProject.Phase18;

public sealed class RealtimeCombatPresenter : MonoBehaviour
{
    [SerializeField] private RealtimeCombatClient client;
    private void Awake()
    {
        if (!client) client = GetComponent<RealtimeCombatClient>();
        if (client) client.CombatResultReceived += OnCombatResult;
    }
    private void OnDestroy() { if (client) client.CombatResultReceived -= OnCombatResult; }
    private void OnCombatResult(CombatResultMessage result)
    {
        if (!result.accepted) Debug.Log("Server rejected combat: " + result.reason);
        else Debug.Log($"Server hit {result.targetId} for {result.damage}. HP={result.targetHealth}");
    }
}
