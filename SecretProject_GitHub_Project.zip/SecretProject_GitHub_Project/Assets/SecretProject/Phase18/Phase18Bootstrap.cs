using UnityEngine;

namespace SecretProject.Phase18;

public sealed class Phase18Bootstrap : MonoBehaviour
{
    [SerializeField] private RealtimeCombatClient combatClient;
    private void Start() { if (combatClient) combatClient.Connect(); }
}
