using System;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace SecretProject.Phase18;

public sealed class RealtimeCombatClient : MonoBehaviour
{
    [SerializeField] private string serverUrl = "ws://127.0.0.1:5000/ws";
    private ClientWebSocket socket;
    private CancellationTokenSource cts;
    private long sequence;

    public bool IsConnected => socket?.State == WebSocketState.Open;
    public event Action<CombatResultMessage> CombatResultReceived;

    public async void Connect(string sessionToken = "")
    {
        if (IsConnected) return;
        socket = new ClientWebSocket();
        cts = new CancellationTokenSource();
        if (!string.IsNullOrWhiteSpace(sessionToken))
            socket.Options.SetRequestHeader("Authorization", "Bearer " + sessionToken);
        try
        {
            await socket.ConnectAsync(new Uri(serverUrl), cts.Token);
            await SendEnvelope(CombatMessageType.Hello, "hello", 0);
            _ = ReceiveLoop();
        }
        catch (Exception ex) { Debug.LogError("Phase18 connect failed: " + ex.Message); }
    }

    public void SendAttack(string attackId, string targetId)
    {
        _ = SendIntent(CombatMessageType.AttackIntent, new AttackIntentMessage
        {
            sequence = Interlocked.Increment(ref sequence), attackId = attackId, targetId = targetId,
            clientTime = Time.time
        });
    }

    public void SendSkill(string skillId, string targetId)
    {
        _ = SendIntent(CombatMessageType.SkillIntent, new SkillIntentMessage
        {
            sequence = Interlocked.Increment(ref sequence), skillId = skillId, targetId = targetId,
            clientTime = Time.time
        });
    }

    private async Task SendIntent(CombatMessageType type, object payload)
    {
        if (!IsConnected) return;
        await SendEnvelope(type, JsonSerializer.Serialize(payload), sequence);
    }

    private async Task SendEnvelope(CombatMessageType type, string payload, long seq)
    {
        var msg = new CombatRealtimeMessage { Type = type, Payload = payload, Sequence = seq };
        var bytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(msg));
        await socket.SendAsync(bytes, WebSocketMessageType.Text, true, cts.Token);
    }

    private async Task ReceiveLoop()
    {
        var buffer = new byte[8192];
        try
        {
            while (IsConnected && !cts.IsCancellationRequested)
            {
                var result = await socket.ReceiveAsync(buffer, cts.Token);
                if (result.MessageType == WebSocketMessageType.Close) break;
                var json = Encoding.UTF8.GetString(buffer, 0, result.Count);
                var envelope = JsonSerializer.Deserialize<CombatRealtimeMessage>(json);
                if (envelope?.Type == CombatMessageType.CombatResult)
                {
                    var combat = JsonSerializer.Deserialize<CombatResultMessage>(envelope.Payload);
                    if (combat != null) CombatResultReceived?.Invoke(combat);
                }
            }
        }
        catch (Exception ex) { Debug.LogWarning("Phase18 receive ended: " + ex.Message); }
    }

    private async void OnDestroy()
    {
        try { cts?.Cancel(); if (socket?.State == WebSocketState.Open) await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "bye", CancellationToken.None); }
        catch { }
        socket?.Dispose(); cts?.Dispose();
    }
}
