using System;
using System.Collections.Generic;
using UnityEngine;

namespace SecretProject.Phase25;

[Serializable]
public sealed class InterestEntityState
{
    public string EntityId;
    public string EntityType;
    public Vector3 Position;
}

[Serializable]
public sealed class InterestDeltaState
{
    public string PlayerId;
    public InterestEntityState[] Entered;
    public string[] Exited;
    public long ServerTick;
}

public sealed class InterestState : MonoBehaviour
{
    private readonly Dictionary<string, InterestEntityState> visible = new();

    public IReadOnlyDictionary<string, InterestEntityState> Visible => visible;

    public void Apply(InterestDeltaState delta)
    {
        if (delta == null) return;

        if (delta.Entered != null)
            foreach (var entity in delta.Entered)
                if (entity != null && !string.IsNullOrWhiteSpace(entity.EntityId))
                    visible[entity.EntityId] = entity;

        if (delta.Exited != null)
            foreach (var id in delta.Exited)
                visible.Remove(id);
    }
}
