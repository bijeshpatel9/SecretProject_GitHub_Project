using UnityEngine;

namespace SecretProject.Phase25;

public sealed class Phase25Bootstrap : MonoBehaviour
{
    [SerializeField] private InterestState interestState;

    private void Awake()
    {
        if (interestState == null)
            interestState = GetComponent<InterestState>();

        if (interestState == null)
            interestState = gameObject.AddComponent<InterestState>();
    }
}
