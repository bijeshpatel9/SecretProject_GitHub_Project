using UnityEngine;
namespace SecretProject.Phase28;
public sealed class Phase28Bootstrap:MonoBehaviour{
 [SerializeField] PlayerResumeState resumeState;
 void Awake(){if(resumeState==null)resumeState=GetComponent<PlayerResumeState>();if(resumeState==null)resumeState=gameObject.AddComponent<PlayerResumeState>();}
}
