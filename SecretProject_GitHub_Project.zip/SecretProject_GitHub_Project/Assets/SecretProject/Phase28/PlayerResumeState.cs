using UnityEngine;
namespace SecretProject.Phase28;
public sealed class PlayerResumeState:MonoBehaviour{
 public bool IsRecovering{get;private set;} public long ServerStateVersion{get;private set;}
 public void BeginRecovery()=>IsRecovering=true;
 public void ApplyAuthoritativeState(Vector3 position,long version){transform.position=position;ServerStateVersion=version;IsRecovering=false;}
 public void RecoveryFailed()=>IsRecovering=false;
}
