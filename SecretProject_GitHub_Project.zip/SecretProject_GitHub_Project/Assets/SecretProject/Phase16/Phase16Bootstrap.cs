using UnityEngine;

namespace SecretProject.Phase16
{
    public class Phase16Bootstrap : MonoBehaviour
    {
        void Awake()
        {
            if (GetComponent<AuthoritativeMovementPresentation>() == null)
                gameObject.AddComponent<AuthoritativeMovementPresentation>();
        }
    }
}
