using UnityEngine;

namespace SecretProject.Phase16
{
    public class AuthoritativeMovementPresentation : MonoBehaviour
    {
        [SerializeField] private float gravity = -25f;
        [SerializeField] private float groundedSnap = -2f;

        public void ApplyServerState(Vector3 position, MovementState state)
        {
            transform.position = position;

            if (state != null)
            {
                // Presentation only. The server remains authoritative.
                if (state.grounded && transform.position.y < 0f)
                    transform.position = new Vector3(transform.position.x, 0f, transform.position.z);
            }
        }
    }
}
