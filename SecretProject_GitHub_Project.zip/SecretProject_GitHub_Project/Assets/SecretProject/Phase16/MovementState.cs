using System;

namespace SecretProject.Phase16
{
    [Serializable]
    public class MovementState
    {
        public bool grounded;
        public bool sprinting;
        public float stamina;
        public float verticalVelocity;
        public long serverTick;
    }
}
