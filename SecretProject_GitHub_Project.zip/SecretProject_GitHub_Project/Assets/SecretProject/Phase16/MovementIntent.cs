using System;
using UnityEngine;

namespace SecretProject.Phase16
{
    [Serializable]
    public class MovementIntent
    {
        public string playerId;
        public long clientTick;
        public Vector3 inputDirection;
        public float requestedYaw;
        public bool wantsSprint;
        public bool jumpRequested;
    }
}
