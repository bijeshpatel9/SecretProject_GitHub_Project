namespace SecretProject.Phase30.Unity;
public sealed class InventoryAuthorityClient {
 public long Version{get;private set;} private readonly System.Collections.Generic.Dictionary<string,long> items=new();
 public void Apply(long version,System.Collections.Generic.IReadOnlyDictionary<string,long> snapshot){if(version<Version)return;Version=version;items.Clear();foreach(var x in snapshot)items[x.Key]=x.Value;}
 public long Quantity(string itemId)=>items.TryGetValue(itemId,out var q)?q:0;
}
