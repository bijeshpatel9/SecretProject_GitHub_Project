using System;
using System.Collections.Generic;

namespace SecretProject.ServerAPI
{
    public class ServerRateLimiter
    {
        readonly Dictionary<string, Queue<DateTime>> requests =
            new Dictionary<string, Queue<DateTime>>();

        public bool Allow(string playerId, int maxRequests, double windowSeconds)
        {
            if (string.IsNullOrEmpty(playerId) || maxRequests <= 0) return false;

            if (!requests.TryGetValue(playerId, out var q))
            {
                q = new Queue<DateTime>();
                requests[playerId] = q;
            }

            DateTime now = DateTime.UtcNow;
            while (q.Count > 0 && (now - q.Peek()).TotalSeconds >= windowSeconds)
                q.Dequeue();

            if (q.Count >= maxRequests) return false;
            q.Enqueue(now);
            return true;
        }
    }
}