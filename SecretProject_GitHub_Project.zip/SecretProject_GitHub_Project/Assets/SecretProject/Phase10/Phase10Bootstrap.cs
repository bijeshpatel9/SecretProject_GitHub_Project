using UnityEngine;

namespace SecretProject.ServerAPI
{
    public class Phase10Bootstrap : MonoBehaviour
    {
        public SecureApiGateway gateway;
        public TransactionSafeRewardService rewards;

        void Awake()
        {
            if (gateway == null) gateway = GetComponent<SecureApiGateway>();
            rewards = new TransactionSafeRewardService();
        }
    }
}