namespace SecretProject.ServerAPI
{
    public static class ServerApiContract
    {
        public const string Login = "POST /v1/auth/session";
        public const string PlayerSnapshot = "GET /v1/player/snapshot";
        public const string Combat = "POST /v1/combat/action";
        public const string SkillUse = "POST /v1/combat/skill";
        public const string BossReward = "POST /v1/boss/reward/commit";
        public const string Inventory = "GET /v1/player/inventory";

        public static bool IsSafePlayerId(string id)
        {
            if (string.IsNullOrEmpty(id) || id.Length > 64) return false;
            foreach (char c in id)
                if (!(char.IsLetterOrDigit(c) || c == '_' || c == '-'))
                    return false;
            return true;
        }
    }
}