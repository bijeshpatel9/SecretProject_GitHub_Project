-- Secret Project Phase 10 reference schema.
-- Use PostgreSQL/MySQL equivalent types as appropriate.

CREATE TABLE players (
    player_id VARCHAR(64) PRIMARY KEY,
    level INT NOT NULL DEFAULT 1,
    experience BIGINT NOT NULL DEFAULT 0,
    gold INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL
);

CREATE TABLE player_skills (
    player_id VARCHAR(64) NOT NULL,
    skill_id VARCHAR(64) NOT NULL,
    unlocked_at TIMESTAMP NOT NULL,
    PRIMARY KEY (player_id, skill_id)
);

CREATE TABLE player_inventory (
    player_id VARCHAR(64) NOT NULL,
    item_id VARCHAR(64) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    PRIMARY KEY (player_id, item_id)
);

CREATE TABLE boss_defeats (
    player_id VARCHAR(64) NOT NULL,
    boss_id VARCHAR(64) NOT NULL,
    ss_plus_skill_id VARCHAR(64) NOT NULL,
    defeat_event_id VARCHAR(128) NOT NULL,
    defeated_at TIMESTAMP NOT NULL,
    PRIMARY KEY (player_id, boss_id),
    UNIQUE (defeat_event_id)
);