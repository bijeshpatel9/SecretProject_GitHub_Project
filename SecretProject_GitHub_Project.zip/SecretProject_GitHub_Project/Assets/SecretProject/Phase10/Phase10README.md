# Secret Project — Phase 10: Server API + Database Foundation

## Included
- Versioned server API contracts
- Login/player/combat/skill/boss/inventory endpoints
- Player and reward request models
- Reference SQL schema
- Transaction-safe boss reward prototype
- Replay/request guard
- Per-player rate limiter
- Secure API gateway validation
- Phase 10 bootstrap

## Critical MMO security model
Client -> Authenticated Session -> API Gateway -> Rate Limit/Replay Check
-> Server Validation -> Database Transaction -> Replicated Result

The client must NEVER decide:
- final damage
- cooldown completion
- boss defeat
- SS+ skill ownership
- inventory ownership
- gold rewards

## Boss reward transaction
A production database transaction should atomically:
1. Verify the server-side boss defeat.
2. Insert (playerId, bossId).
3. Insert the SS+ skill ownership.
4. Commit both, or roll both back.

The PRIMARY KEY on (player_id, boss_id) and UNIQUE defeat_event_id
provide duplicate protection at the database layer.

## Important
This package is an architecture/prototype and does not include a real
network server or live database connection. For production, connect these
contracts to a dedicated authoritative server and database.

## Next
Phase 11: production server implementation, real database repository,
authentication provider integration, secure transport, and live API handlers.
