using System.Collections.Generic;

namespace SecretProject.ServerAPI
{
    public class RequestReplayGuard
    {
        readonly HashSet<string> processedRequestIds = new HashSet<string>();

        public bool TryAccept(string requestId)
        {
            if (string.IsNullOrEmpty(requestId)) return false;
            return processedRequestIds.Add(requestId);
        }
    }
}