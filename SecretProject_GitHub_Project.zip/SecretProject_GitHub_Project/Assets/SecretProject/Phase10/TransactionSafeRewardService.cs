using System;
using System.Collections.Generic;

namespace SecretProject.ServerAPI
{
    public class TransactionSafeRewardService
    {
        readonly HashSet<string> committedBosses = new HashSet<string>();
        readonly HashSet<string> eventIds = new HashSet<string>();

        public ApiResponse CommitBossReward(BossRewardRequest request)
        {
            if (request == null)
                return Fail("INVALID_REQUEST", "Request is null.");

            if (string.IsNullOrEmpty(request.playerId) ||
                string.IsNullOrEmpty(request.bossId) ||
                string.IsNullOrEmpty(request.ssPlusSkillId) ||
                string.IsNullOrEmpty(request.defeatEventId))
                return Fail("INVALID_REQUEST", "Required reward fields are missing.");

            if (!eventIds.Add(request.defeatEventId))
                return Fail("DUPLICATE_EVENT", "Reward event was already processed.");

            string bossKey = request.playerId + ":" + request.bossId;
            if (!committedBosses.Add(bossKey))
            {
                eventIds.Remove(request.defeatEventId);
                return Fail("BOSS_ALREADY_REWARDED", "This player already received this boss reward.");
            }

            // Production implementation: wrap boss_defeats INSERT and skill INSERT
            // in one database transaction. Roll back both if either operation fails.
            return new ApiResponse
            {
                success = true,
                message = "Boss defeat and SS+ ownership committed."
            };
        }

        static ApiResponse Fail(string code, string message)
        {
            return new ApiResponse { success = false, errorCode = code, message = message };
        }
    }
}