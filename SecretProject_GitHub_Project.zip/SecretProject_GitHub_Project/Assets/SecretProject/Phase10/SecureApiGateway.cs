using UnityEngine;

namespace SecretProject.ServerAPI
{
    public class SecureApiGateway : MonoBehaviour
    {
        readonly RequestReplayGuard replayGuard = new RequestReplayGuard();
        readonly ServerRateLimiter rateLimiter = new ServerRateLimiter();

        public bool ValidateRequest(string playerId, string requestId)
        {
            if (!ServerApiContract.IsSafePlayerId(playerId)) return false;
            if (!rateLimiter.Allow(playerId, 30, 1.0)) return false;
            if (!replayGuard.TryAccept(requestId)) return false;
            return true;
        }
    }
}