using System;
using System.Collections.Generic;

namespace SecretProject.ServerAPI
{
    [Serializable]
    public class LoginRequest { public string playerId; public string sessionToken; }

    [Serializable]
    public class CombatRequest
    {
        public string playerId;
        public string attackId;
        public float clientTime;
        public string targetId;
    }

    [Serializable]
    public class SkillUseRequest
    {
        public string playerId;
        public string skillId;
        public string targetId;
    }

    [Serializable]
    public class BossRewardRequest
    {
        public string playerId;
        public string bossId;
        public string ssPlusSkillId;
        public string defeatEventId;
    }

    [Serializable]
    public class ApiResponse
    {
        public bool success;
        public string errorCode;
        public string message;
    }

    [Serializable]
    public class PlayerSnapshot
    {
        public string playerId;
        public int level;
        public long experience;
        public int gold;
        public List<string> inventory = new List<string>();
        public List<string> unlockedSkills = new List<string>();
        public List<string> defeatedBossIds = new List<string>();
    }
}