using System;
using System.Collections.Generic;

namespace SecretProject.Phase29.Unity;

public sealed class Phase29StateClient
{
    public UnityPersistentPlayerState AuthoritativeState { get; private set; }
    public event Action<UnityPersistentPlayerState> StateRestored;

    public void ApplyServerSnapshot(UnityPersistentPlayerState snapshot)
    {
        if (snapshot == null) return;
        if (AuthoritativeState != null && snapshot.stateVersion < AuthoritativeState.stateVersion)
            return;
        AuthoritativeState = snapshot;
        StateRestored?.Invoke(snapshot);
    }

    public IReadOnlyList<UnityItemStack> Inventory =>
        AuthoritativeState?.inventory ?? Array.Empty<UnityItemStack>();
}
