using System;
using System.Collections.Generic;

namespace SecretProject.Phase29.Unity;

[Serializable] public sealed class UnityItemStack { public string itemId; public int quantity; public int version; }

[Serializable] public sealed class UnityPersistentPlayerState
{
    public string playerId;
    public string worldId;
    public string shardId;
    public int level;
    public long experience;
    public int hp, maxHp, mana, maxMana;
    public List<UnityItemStack> inventory = new();
    public long stateVersion;
}
