# Secret Project — GitHub Android Build Project

This folder is arranged so the **contents of this folder** can be uploaded to the root of a GitHub repository.

## Unity version
Unity 2022.3.62f2

## GitHub upload
1. Create a new GitHub repository.
2. Upload **all contents of this folder** (not the outer ZIP itself) to the repository root.
3. Commit to the `main` branch.
4. Open **Actions** → **Build Android APK** → **Run workflow**.
5. After the build completes, open the workflow run and download the artifact named **SecretProject-Android-APK**.

The workflow is already located at:
`.github/workflows/build-android.yml`

## Important
- GitHub does not need PostgreSQL or Redis installed on the Android phone.
- PostgreSQL, Redis, and MMO backend services belong on a server/cloud environment.
- The GitHub workflow builds the Unity client APK only.
- Unity licensing/credentials required by the selected cloud build method must be configured in GitHub repository secrets.

## Main Android output
`Builds/Android/SecretProject.apk`
