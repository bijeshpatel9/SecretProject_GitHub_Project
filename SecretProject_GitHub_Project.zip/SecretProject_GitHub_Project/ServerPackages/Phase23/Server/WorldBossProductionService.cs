namespace SecretProjectServer.Phase23;

public sealed class WorldBossProductionService
{
    private readonly IProductionWorldBossRepository repository;

    public WorldBossProductionService(IProductionWorldBossRepository repository)
    {
        this.repository = repository;
    }

    public Task<IReadOnlyList<WorldBossInstanceRow>> RecoverAsync(
        string worldId, string shardId, CancellationToken ct)
        => repository.GetActiveAsync(worldId, shardId, ct);

    public Task<bool> CheckpointAsync(
        string instanceId, float health, int phase, bool active, bool defeated,
        long expectedVersion, long tick, CancellationToken ct)
        => repository.UpdateCheckpointAsync(
            instanceId, health, phase, active, defeated, expectedVersion, tick, ct);

    public Task<bool> DefeatAsync(
        string instanceId, long expectedVersion, CancellationToken ct)
        => repository.MarkDefeatedTransactionallyAsync(
            instanceId, expectedVersion, ct);
}
