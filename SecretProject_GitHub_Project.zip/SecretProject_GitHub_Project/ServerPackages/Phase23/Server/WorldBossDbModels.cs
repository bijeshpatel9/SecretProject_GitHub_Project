namespace SecretProjectServer.Phase23;

public sealed class WorldBossInstanceRow
{
    public required string InstanceId { get; set; }
    public required string WorldId { get; set; }
    public required string ShardId { get; set; }
    public required string ZoneId { get; set; }
    public required string BossId { get; set; }
    public float Health { get; set; }
    public float MaxHealth { get; set; }
    public int Phase { get; set; }
    public bool Active { get; set; }
    public bool Defeated { get; set; }
    public long SpawnTick { get; set; }
    public long Version { get; set; }
    public DateTime UpdatedAtUtc { get; set; }
}

public sealed class WorldBossCheckpointRow
{
    public required string InstanceId { get; set; }
    public float Health { get; set; }
    public int Phase { get; set; }
    public bool Active { get; set; }
    public bool Defeated { get; set; }
    public long Version { get; set; }
    public long CheckpointTick { get; set; }
    public DateTime UpdatedAtUtc { get; set; }
}
