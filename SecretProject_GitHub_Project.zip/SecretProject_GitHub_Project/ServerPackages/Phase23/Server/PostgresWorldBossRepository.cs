using System.Data;
using Npgsql;

namespace SecretProjectServer.Phase23;

public sealed class PostgresWorldBossRepository : IProductionWorldBossRepository
{
    private readonly string connectionString;

    public PostgresWorldBossRepository(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public async Task<WorldBossInstanceRow?> GetAsync(string instanceId, CancellationToken ct)
    {
        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);

        const string sql = """
            SELECT instance_id, world_id, shard_id, zone_id, boss_id,
                   health, max_health, phase, active, defeated,
                   spawn_tick, version, updated_at
            FROM world_boss_instances
            WHERE instance_id = @id
            """;

        await using var cmd = new NpgsqlCommand(sql, db);
        cmd.Parameters.AddWithValue("id", instanceId);

        await using var r = await cmd.ExecuteReaderAsync(ct);
        if (!await r.ReadAsync(ct)) return null;

        return new WorldBossInstanceRow
        {
            InstanceId = r.GetString(0),
            WorldId = r.GetString(1),
            ShardId = r.GetString(2),
            ZoneId = r.GetString(3),
            BossId = r.GetString(4),
            Health = r.GetFloat(5),
            MaxHealth = r.GetFloat(6),
            Phase = r.GetInt32(7),
            Active = r.GetBoolean(8),
            Defeated = r.GetBoolean(9),
            SpawnTick = r.GetInt64(10),
            Version = r.GetInt64(11),
            UpdatedAtUtc = r.GetDateTime(12)
        };
    }

    public async Task<IReadOnlyList<WorldBossInstanceRow>> GetActiveAsync(
        string worldId, string shardId, CancellationToken ct)
    {
        var result = new List<WorldBossInstanceRow>();

        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);

        const string sql = """
            SELECT instance_id, world_id, shard_id, zone_id, boss_id,
                   health, max_health, phase, active, defeated,
                   spawn_tick, version, updated_at
            FROM world_boss_instances
            WHERE world_id = @world AND shard_id = @shard
              AND active = TRUE AND defeated = FALSE
            """;

        await using var cmd = new NpgsqlCommand(sql, db);
        cmd.Parameters.AddWithValue("world", worldId);
        cmd.Parameters.AddWithValue("shard", shardId);

        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct))
        {
            result.Add(new WorldBossInstanceRow
            {
                InstanceId = r.GetString(0),
                WorldId = r.GetString(1),
                ShardId = r.GetString(2),
                ZoneId = r.GetString(3),
                BossId = r.GetString(4),
                Health = r.GetFloat(5),
                MaxHealth = r.GetFloat(6),
                Phase = r.GetInt32(7),
                Active = r.GetBoolean(8),
                Defeated = r.GetBoolean(9),
                SpawnTick = r.GetInt64(10),
                Version = r.GetInt64(11),
                UpdatedAtUtc = r.GetDateTime(12)
            });
        }

        return result;
    }

    public async Task<bool> CreateOnceAsync(WorldBossInstanceRow row, CancellationToken ct)
    {
        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);

        const string sql = """
            INSERT INTO world_boss_instances
              (instance_id, world_id, shard_id, zone_id, boss_id,
               health, max_health, phase, active, defeated, spawn_tick, version, updated_at)
            VALUES
              (@id, @world, @shard, @zone, @boss,
               @hp, @maxhp, @phase, TRUE, FALSE, @tick, 1, NOW())
            ON CONFLICT (world_id, boss_id) DO NOTHING
            """;

        await using var cmd = new NpgsqlCommand(sql, db);
        cmd.Parameters.AddWithValue("id", row.InstanceId);
        cmd.Parameters.AddWithValue("world", row.WorldId);
        cmd.Parameters.AddWithValue("shard", row.ShardId);
        cmd.Parameters.AddWithValue("zone", row.ZoneId);
        cmd.Parameters.AddWithValue("boss", row.BossId);
        cmd.Parameters.AddWithValue("hp", row.Health);
        cmd.Parameters.AddWithValue("maxhp", row.MaxHealth);
        cmd.Parameters.AddWithValue("phase", row.Phase);
        cmd.Parameters.AddWithValue("tick", row.SpawnTick);

        return await cmd.ExecuteNonQueryAsync(ct) == 1;
    }

    public async Task<bool> UpdateCheckpointAsync(
        string instanceId, float health, int phase, bool active, bool defeated,
        long expectedVersion, long checkpointTick, CancellationToken ct)
    {
        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);

        const string sql = """
            UPDATE world_boss_instances
            SET health=@hp, phase=@phase, active=@active, defeated=@defeated,
                version=version+1, updated_at=NOW()
            WHERE instance_id=@id AND version=@version
            """;

        await using var cmd = new NpgsqlCommand(sql, db);
        cmd.Parameters.AddWithValue("hp", health);
        cmd.Parameters.AddWithValue("phase", phase);
        cmd.Parameters.AddWithValue("active", active);
        cmd.Parameters.AddWithValue("defeated", defeated);
        cmd.Parameters.AddWithValue("id", instanceId);
        cmd.Parameters.AddWithValue("version", expectedVersion);

        return await cmd.ExecuteNonQueryAsync(ct) == 1;
    }

    public async Task<bool> MarkDefeatedTransactionallyAsync(
        string instanceId, long expectedVersion, CancellationToken ct)
    {
        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);
        await using var tx = await db.BeginTransactionAsync(IsolationLevel.Serializable, ct);

        const string sql = """
            UPDATE world_boss_instances
            SET health=0, active=FALSE, defeated=TRUE,
                version=version+1, updated_at=NOW()
            WHERE instance_id=@id AND version=@version
              AND active=TRUE AND defeated=FALSE
            """;

        await using var cmd = new NpgsqlCommand(sql, db, tx);
        cmd.Parameters.AddWithValue("id", instanceId);
        cmd.Parameters.AddWithValue("version", expectedVersion);

        var changed = await cmd.ExecuteNonQueryAsync(ct);
        if (changed != 1)
        {
            await tx.RollbackAsync(ct);
            return false;
        }

        await tx.CommitAsync(ct);
        return true;
    }
}
