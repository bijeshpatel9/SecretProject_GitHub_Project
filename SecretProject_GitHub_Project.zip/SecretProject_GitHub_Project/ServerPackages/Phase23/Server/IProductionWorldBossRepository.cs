namespace SecretProjectServer.Phase23;

public interface IProductionWorldBossRepository
{
    Task<WorldBossInstanceRow?> GetAsync(string instanceId, CancellationToken ct);
    Task<IReadOnlyList<WorldBossInstanceRow>> GetActiveAsync(
        string worldId, string shardId, CancellationToken ct);

    Task<bool> CreateOnceAsync(
        WorldBossInstanceRow row, CancellationToken ct);

    Task<bool> UpdateCheckpointAsync(
        string instanceId,
        float health,
        int phase,
        bool active,
        bool defeated,
        long expectedVersion,
        long checkpointTick,
        CancellationToken ct);

    Task<bool> MarkDefeatedTransactionallyAsync(
        string instanceId,
        long expectedVersion,
        CancellationToken ct);
}
