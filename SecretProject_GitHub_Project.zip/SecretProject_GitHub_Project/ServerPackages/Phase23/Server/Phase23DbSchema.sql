-- Phase 23 production-oriented schema foundation.
-- PostgreSQL is recommended for production.
CREATE TABLE IF NOT EXISTS world_boss_instances (
    instance_id TEXT PRIMARY KEY,
    world_id TEXT NOT NULL,
    shard_id TEXT NOT NULL,
    zone_id TEXT NOT NULL,
    boss_id TEXT NOT NULL,
    health REAL NOT NULL,
    max_health REAL NOT NULL,
    phase INTEGER NOT NULL,
    active BOOLEAN NOT NULL,
    defeated BOOLEAN NOT NULL,
    spawn_tick BIGINT NOT NULL,
    version BIGINT NOT NULL DEFAULT 1,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_world_boss UNIQUE (world_id, boss_id)
);

CREATE INDEX IF NOT EXISTS ix_world_boss_active
ON world_boss_instances(world_id, shard_id, zone_id, active);

CREATE TABLE IF NOT EXISTS world_boss_checkpoints (
    instance_id TEXT PRIMARY KEY REFERENCES world_boss_instances(instance_id),
    health REAL NOT NULL,
    phase INTEGER NOT NULL,
    active BOOLEAN NOT NULL,
    defeated BOOLEAN NOT NULL,
    version BIGINT NOT NULL,
    checkpoint_tick BIGINT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
