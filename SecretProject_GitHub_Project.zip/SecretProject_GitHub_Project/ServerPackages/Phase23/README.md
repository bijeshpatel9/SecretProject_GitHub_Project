# Secret Project — Phase 23

## Production Database World/Boss Persistence

Phase 23 upgrades Phase 22's development JSON persistence toward a production database model.

### Added
- PostgreSQL-oriented world boss schema.
- Unique `(world_id, boss_id)` constraint for one-time boss existence.
- Persistent active boss instances.
- Optimistic concurrency using a `version` column.
- Periodic boss state checkpoint API.
- Serializable transactional boss defeat.
- Server restart/recovery queries by world + shard.
- Repository abstraction so the game server can swap database implementations.

### Security / authority
The database remains authoritative. Client messages never directly write boss state.
The server validates combat and then persists the resulting state.

### Production requirements before launch
- Use PostgreSQL or managed SQL, not JSON.
- Add EF Core/Npgsql migrations rather than manual schema deployment.
- Store secrets in a secrets manager.
- Add backups, point-in-time recovery and disaster recovery.
- Add audit logs for boss spawn/checkpoint/defeat.
- Use distributed locking/ownership for shard leadership.
- Define checkpoint frequency and crash-consistency policy.
- Integrate Phase 18 WebSocket, Phase 20 boss simulation and Phase 21/22 instance lifecycle.
