# Production checklist

- [ ] PostgreSQL schema/migrations for player, guild, inventory, escrow, marketplace, quests and world flags.
- [ ] Redis for short-lived locks, rate limits and matchmaking queues.
- [ ] Durable Kafka/RabbitMQ/etc. outbox/inbox with dedupe keys.
- [ ] Shard fencing and lease ownership for every authoritative player/world partition.
- [ ] TLS, secret vault, token rotation and platform receipt verification.
- [ ] Server-side anti-cheat telemetry and review tooling.
- [ ] Unity Android/iOS IL2CPP builds, crash reporting, remote config and asset bundles.
- [ ] Load/soak tests for shards, dungeons, world bosses, auction house and guild wars.
- [ ] Backup restore drills and RPO/RTO validation.
- [ ] App-store compliance, privacy policy, age/content controls and payment compliance.
