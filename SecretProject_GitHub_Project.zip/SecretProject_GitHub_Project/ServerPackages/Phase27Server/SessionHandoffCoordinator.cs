namespace SecretProjectServer.Phase27;
public sealed class SessionHandoffCoordinator {
 readonly DistributedSessionStore store; readonly Dictionary<string,SessionHandoffTicket> tickets=new();
 public SessionHandoffCoordinator(DistributedSessionStore s)=>store=s;
 public bool TryPrepare(string player,string session,string transfer,string from,string to,long tick,out SessionHandoffTicket? ticket){ ticket=null; if(!store.TryGet(session,out var s)||s!.PlayerId!=player||!s.Authenticated||s.NodeId!=from)return false; var id=Guid.NewGuid().ToString("N"); ticket=new(id,player,session,from,to,tick,tick+150); tickets[id]=ticket; return true; }
 public bool TryCommit(string id,long tick,out SessionHandoffTicket? ticket){ ticket=null; if(!tickets.TryGetValue(id,out var t)||tick>t.ExpiresTick)return false; tickets.Remove(id); ticket=t; return true; }
}
