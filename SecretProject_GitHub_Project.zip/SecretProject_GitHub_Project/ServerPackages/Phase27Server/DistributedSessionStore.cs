namespace SecretProjectServer.Phase27;
public sealed record DistributedSession(string SessionId,string PlayerId,string NodeId,bool Authenticated,long LastSequence,long Version);
public sealed class DistributedSessionStore {
 readonly Dictionary<string,DistributedSession> sessions=new();
 public void Upsert(DistributedSession s)=>sessions[s.SessionId]=s;
 public bool TryGet(string id,out DistributedSession? s)=>sessions.TryGetValue(id,out s);
 public bool TryMove(string id,string node,long expected,out DistributedSession? moved){ moved=null; if(!sessions.TryGetValue(id,out var cur)||!cur.Authenticated||cur.Version!=expected)return false; moved=cur with{NodeId=node,Version=cur.Version+1}; sessions[id]=moved; return true; }
}
