namespace SecretProjectServer.Phase27;
public sealed class Phase27AuthHandoffService {
 readonly DistributedSessionStore store; readonly SessionHandoffCoordinator coord; readonly SessionReplayGuard replay;
 public Phase27AuthHandoffService(DistributedSessionStore s,SessionHandoffCoordinator c,SessionReplayGuard r){store=s;coord=c;replay=r;}
 public bool Prepare(SessionTransferRequest r,long tick,out SessionHandoffTicket? t){t=null;if(!replay.Accept(r.SessionId,r.ClientSequence))return false;return coord.TryPrepare(r.PlayerId,r.SessionId,r.TransferTicketId,r.FromNodeId,r.ToNodeId,tick,out t);}
 public bool Commit(string id,long tick,out SessionHandoffResult result){result=new(false,id,"Rejected");if(!coord.TryCommit(id,tick,out var t))return false;if(!store.TryGet(t!.SessionId,out var s))return false;if(!store.TryMove(t.SessionId,t.ToNodeId,s!.Version,out _))return false;result=new(true,id,"Committed");return true;}
}
