namespace SecretProjectServer.Phase27;
public sealed record SessionTransferRequest(string PlayerId,string SessionId,string TransferTicketId,string FromNodeId,string ToNodeId,long ClientSequence);
public sealed record SessionHandoffTicket(string HandoffId,string PlayerId,string SessionId,string FromNodeId,string ToNodeId,long IssuedTick,long ExpiresTick);
public sealed record SessionHandoffResult(bool Accepted,string HandoffId,string Reason);
