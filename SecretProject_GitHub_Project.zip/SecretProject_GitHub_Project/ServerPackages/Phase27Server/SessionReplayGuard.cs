namespace SecretProjectServer.Phase27;
public sealed class SessionReplayGuard { readonly Dictionary<string,long> last=new(); public bool Accept(string id,long seq){if(last.TryGetValue(id,out var p)&&seq<=p)return false; last[id]=seq; return true;} }
