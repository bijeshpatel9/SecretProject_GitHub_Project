using System;
using System.Collections.Generic;

namespace SecretProject.Shared {
 public readonly record struct VersionedId(string Id, long Version);
 public readonly record struct CommandContext(string PlayerId,string RequestId,string ShardId,DateTimeOffset Now);
 public sealed record Result<T>(bool Success,T? Value,string? Error,long Version=0) {
  public static Result<T> Ok(T value,long version=0)=>new(true,value,null,version);
  public static Result<T> Fail(string error)=>new(false,default,error,0);
 }
 public interface IVersionedStore<T> { Result<T> Get(string id); Result<T> Put(string id,T value,long expectedVersion); }
 public interface IIdempotencyStore { bool Seen(string key); void Mark(string key); }
 public sealed class MemoryIdempotency : IIdempotencyStore { readonly HashSet<string> keys=new(); public bool Seen(string k)=>keys.Contains(k); public void Mark(string k)=>keys.Add(k); }
 public static class Guard { public static void NotBlank(string s,string n){if(string.IsNullOrWhiteSpace(s)) throw new ArgumentException(n);} public static void Positive(long n,string name){if(n<=0) throw new ArgumentOutOfRangeException(name);} }
}
