namespace SecretProjectServer.Phase26;

public sealed class Phase26ConnectionRouter
{
    private readonly ShardNodeRegistry registry;

    public Phase26ConnectionRouter(ShardNodeRegistry registry) => this.registry=registry;

    public bool TryGetWebSocketTarget(string worldId,string shardId,string zoneId,out string? nodeId)
    {
        nodeId=null;
        if (!registry.TryFindTarget(worldId,shardId,zoneId,out var node)) return false;
        nodeId=node!.NodeId;
        return true;
    }
}
