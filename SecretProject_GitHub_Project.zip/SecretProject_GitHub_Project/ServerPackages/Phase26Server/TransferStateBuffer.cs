namespace SecretProjectServer.Phase26;

public sealed class TransferStateBuffer
{
    private readonly Dictionary<string,byte[]> state=new();

    public void Save(string playerId,byte[] snapshot) => state[playerId]=snapshot;
    public bool TryLoad(string playerId,out byte[]? snapshot)=>state.TryGetValue(playerId,out snapshot);
    public void Remove(string playerId)=>state.Remove(playerId);
}
