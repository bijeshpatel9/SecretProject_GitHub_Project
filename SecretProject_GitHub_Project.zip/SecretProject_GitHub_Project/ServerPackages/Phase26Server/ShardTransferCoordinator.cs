namespace SecretProjectServer.Phase26;

public sealed class ShardTransferCoordinator
{
    private readonly ShardNodeRegistry registry;
    private readonly Dictionary<string,PlayerTransferTicket> activeTickets=new();

    public ShardTransferCoordinator(ShardNodeRegistry registry) => this.registry=registry;

    public bool TryBegin(PlayerTransferRequest request,long serverTick,out PlayerTransferResult result)
    {
        result=new(false,"","","","Invalid");
        if (string.IsNullOrWhiteSpace(request.PlayerId) ||
            request.WorldId != request.WorldId ||
            request.FromShardId == request.ToShardId)
        {
            result=result with {Reason="InvalidTransfer"};
            return false;
        }

        if (!registry.TryFindTarget(request.WorldId,request.ToShardId,request.ToZoneId,out var node))
        {
            result=result with {Reason="TargetUnavailable"};
            return false;
        }

        var ticketId=Guid.NewGuid().ToString("N");
        var ticket=new PlayerTransferTicket(ticketId,request.PlayerId,request.WorldId,
            request.FromShardId,request.ToShardId,request.FromZoneId,request.ToZoneId,
            serverTick,serverTick+300);
        activeTickets[request.PlayerId]=ticket;
        result=new(true,ticketId,node!.NodeId,serverTick,"Accepted");
        return true;
    }

    public bool TryCommit(string playerId,string ticketId,long serverTick,out PlayerTransferTicket? ticket)
    {
        ticket=null;
        if (!activeTickets.TryGetValue(playerId,out var t)) return false;
        if (t.TicketId!=ticketId || serverTick>t.ExpiresTick) return false;
        activeTickets.Remove(playerId);
        ticket=t;
        return true;
    }

    public void Cancel(string playerId) => activeTickets.Remove(playerId);
}
