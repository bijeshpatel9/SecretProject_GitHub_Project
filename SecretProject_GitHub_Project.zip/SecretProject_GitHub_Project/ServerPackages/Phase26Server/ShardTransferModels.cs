namespace SecretProjectServer.Phase26;

public sealed record PlayerTransferRequest(
    string PlayerId, string WorldId, string FromShardId, string ToShardId,
    string FromZoneId, string ToZoneId, long ClientSequence);

public sealed record PlayerTransferTicket(
    string TicketId, string PlayerId, string WorldId,
    string FromShardId, string ToShardId, string FromZoneId, string ToZoneId,
    long IssuedTick, long ExpiresTick);

public sealed record PlayerTransferResult(
    bool Accepted, string TicketId, string TargetNodeId, long ServerTick, string Reason);
