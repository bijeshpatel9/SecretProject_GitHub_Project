namespace SecretProjectServer.Phase26;

public sealed record ShardNode(
    string NodeId, string WorldId, string ShardId, string ZoneId,
    bool Healthy, int Capacity, int ActivePlayers);

public sealed class ShardNodeRegistry
{
    private readonly Dictionary<string, ShardNode> nodes = new();

    public void Upsert(ShardNode node) => nodes[Key(node.WorldId,node.ShardId,node.ZoneId)] = node;

    public bool TryResolve(string worldId,string shardId,string zoneId,out ShardNode? node)
        => nodes.TryGetValue(Key(worldId,shardId,zoneId),out node);

    public bool TryFindTarget(string worldId,string shardId,string zoneId,out ShardNode? node)
    {
        if (TryResolve(worldId,shardId,zoneId,out node) &&
            node!.Healthy && node.ActivePlayers < node.Capacity) return true;
        node=null; return false;
    }

    private static string Key(string w,string s,string z)=>$"{w}:{s}:{z}";
}
