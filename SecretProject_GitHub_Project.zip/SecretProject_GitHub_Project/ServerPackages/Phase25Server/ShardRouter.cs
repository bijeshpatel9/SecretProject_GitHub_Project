namespace SecretProjectServer.Phase25;

public sealed record ShardRoute(string WorldId, string ShardId, string ZoneId, string NodeId);

public sealed class ShardRouter
{
    private readonly Dictionary<string, ShardRoute> routes = new();

    public void Register(ShardRoute route)
        => routes[Key(route.WorldId, route.ShardId, route.ZoneId)] = route;

    public bool TryResolve(string worldId, string shardId, string zoneId, out ShardRoute? route)
        => routes.TryGetValue(Key(worldId, shardId, zoneId), out route);

    public bool IsValidRoute(string worldId, string shardId, string zoneId)
        => routes.ContainsKey(Key(worldId, shardId, zoneId));

    private static string Key(string world, string shard, string zone)
        => $"{world}:{shard}:{zone}";
}
