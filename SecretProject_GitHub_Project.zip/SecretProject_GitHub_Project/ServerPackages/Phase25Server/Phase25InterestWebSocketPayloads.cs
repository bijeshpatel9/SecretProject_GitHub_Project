using System.Text.Json;

namespace SecretProjectServer.Phase25;

public static class Phase25InterestPayloads
{
    public static byte[] Serialize(InterestDelta delta)
        => JsonSerializer.SerializeToUtf8Bytes(new
        {
            type = "interest_delta",
            playerId = delta.PlayerId,
            entered = delta.Entered,
            exited = delta.Exited,
            serverTick = delta.ServerTick
        });
}
