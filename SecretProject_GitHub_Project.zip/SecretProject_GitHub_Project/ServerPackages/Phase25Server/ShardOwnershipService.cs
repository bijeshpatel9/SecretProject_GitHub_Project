namespace SecretProjectServer.Phase25;

public sealed class ShardOwnershipService
{
    private readonly Dictionary<string, string> owners = new();

    public bool TryClaim(string shardKey, string nodeId)
    {
        if (owners.TryGetValue(shardKey, out var owner))
            return owner == nodeId;

        owners[shardKey] = nodeId;
        return true;
    }

    public bool IsOwner(string shardKey, string nodeId)
        => owners.TryGetValue(shardKey, out var owner) && owner == nodeId;

    public void Release(string shardKey, string nodeId)
    {
        if (IsOwner(shardKey, nodeId))
            owners.Remove(shardKey);
    }
}
