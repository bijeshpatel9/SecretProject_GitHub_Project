using System.Numerics;

namespace SecretProjectServer.Phase25;

public sealed record InterestEntity(
    string EntityId,
    string WorldId,
    string ShardId,
    string ZoneId,
    Vector3 Position,
    string EntityType);

public sealed record InterestSubscription(
    string PlayerId,
    string WorldId,
    string ShardId,
    string ZoneId,
    float Radius);

public sealed record InterestDelta(
    string PlayerId,
    IReadOnlyList<InterestEntity> Entered,
    IReadOnlyList<string> Exited,
    long ServerTick);
