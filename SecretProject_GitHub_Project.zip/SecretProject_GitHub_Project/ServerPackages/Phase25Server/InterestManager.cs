using System.Numerics;

namespace SecretProjectServer.Phase25;

public sealed class InterestManager
{
    private readonly InterestGrid grid;
    private readonly Dictionary<string, InterestEntity> entities = new();
    private readonly Dictionary<string, HashSet<string>> visibleByPlayer = new();

    public InterestManager(float cellSize = 32f)
    {
        grid = new InterestGrid(cellSize);
    }

    public void Upsert(InterestEntity entity)
    {
        entities[entity.EntityId] = entity;
        grid.Upsert(entity);
    }

    public void Remove(string entityId)
    {
        entities.Remove(entityId);
        grid.Remove(entityId);

        foreach (var visible in visibleByPlayer.Values)
            visible.Remove(entityId);
    }

    public InterestDelta Recalculate(
        InterestSubscription subscription,
        Vector3 playerPosition,
        long serverTick)
    {
        var next = new HashSet<string>();

        foreach (var id in grid.Query(playerPosition, subscription.Radius))
        {
            if (!entities.TryGetValue(id, out var entity)) continue;

            if (entity.WorldId != subscription.WorldId ||
                entity.ShardId != subscription.ShardId ||
                entity.ZoneId != subscription.ZoneId)
                continue;

            var dx = entity.Position.X - playerPosition.X;
            var dz = entity.Position.Z - playerPosition.Z;

            if (dx * dx + dz * dz <= subscription.Radius * subscription.Radius)
                next.Add(id);
        }

        if (!visibleByPlayer.TryGetValue(subscription.PlayerId, out var old))
            visibleByPlayer[subscription.PlayerId] = old = new HashSet<string>();

        var entered = next.Where(id => !old.Contains(id))
            .Select(id => entities[id]).ToList();
        var exited = old.Where(id => !next.Contains(id)).ToList();

        visibleByPlayer[subscription.PlayerId] = next;

        return new InterestDelta(subscription.PlayerId, entered, exited, serverTick);
    }
}
