using System.Numerics;

namespace SecretProjectServer.Phase25;

public sealed class InterestGrid
{
    private readonly float cellSize;
    private readonly Dictionary<(int X, int Z), HashSet<string>> cells = new();
    private readonly Dictionary<string, (int X, int Z)> entityCells = new();

    public InterestGrid(float cellSize = 32f)
    {
        this.cellSize = Math.Max(1f, cellSize);
    }

    public void Upsert(InterestEntity entity)
    {
        var next = Cell(entity.Position);

        if (entityCells.TryGetValue(entity.EntityId, out var old) && old != next)
        {
            if (cells.TryGetValue(old, out var oldSet))
            {
                oldSet.Remove(entity.EntityId);
                if (oldSet.Count == 0) cells.Remove(old);
            }
        }

        if (!cells.TryGetValue(next, out var set))
            cells[next] = set = new HashSet<string>();

        set.Add(entity.EntityId);
        entityCells[entity.EntityId] = next;
    }

    public void Remove(string entityId)
    {
        if (!entityCells.Remove(entityId, out var cell)) return;
        if (!cells.TryGetValue(cell, out var set)) return;

        set.Remove(entityId);
        if (set.Count == 0) cells.Remove(cell);
    }

    public IEnumerable<string> Query(Vector3 center, float radius)
    {
        var minX = (int)MathF.Floor((center.X - radius) / cellSize);
        var maxX = (int)MathF.Floor((center.X + radius) / cellSize);
        var minZ = (int)MathF.Floor((center.Z - radius) / cellSize);
        var maxZ = (int)MathF.Floor((center.Z + radius) / cellSize);

        for (var x = minX; x <= maxX; x++)
        for (var z = minZ; z <= maxZ; z++)
        {
            if (!cells.TryGetValue((x, z), out var set)) continue;
            foreach (var id in set) yield return id;
        }
    }

    private (int X, int Z) Cell(Vector3 p)
        => ((int)MathF.Floor(p.X / cellSize), (int)MathF.Floor(p.Z / cellSize));
}
