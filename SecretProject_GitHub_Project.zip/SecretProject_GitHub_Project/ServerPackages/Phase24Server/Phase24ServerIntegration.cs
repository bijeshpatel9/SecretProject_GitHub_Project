namespace SecretProjectServer.Phase24;

public static class Phase24ServerIntegration
{
    // Register these services in the existing .NET 8 server:
    // builder.Services.AddSingleton<IPhase24BossLifecycleRepository>(
    //     _ => new PostgresBossLifecycleRepository(connectionString));
    // builder.Services.AddSingleton<BossLifecycleCoordinator>();
    // builder.Services.AddSingleton<Phase24WebSocketBossBroadcaster>();
    //
    // The existing Phase 18 WebSocket endpoint should authenticate the
    // session before adding a socket to the broadcaster.
}
