namespace SecretProjectServer.Phase24;

public sealed class BossLifecycleCoordinator
{
    private readonly IPhase24BossLifecycleRepository repository;
    private readonly Dictionary<string, long> ticks = new();

    public BossLifecycleCoordinator(IPhase24BossLifecycleRepository repository)
    {
        this.repository = repository;
    }

    public async Task<BossLifecycleSnapshot?> RecoverAsync(
        string worldId, string shardId, CancellationToken ct)
    {
        var active = await repository.GetActiveAsync(worldId, shardId, ct);
        return active.Count == 0 ? null : active[0];
    }

    public async Task<bool> CheckpointAsync(
        BossLifecycleSnapshot snapshot, CancellationToken ct)
    {
        var ok = await repository.TryCheckpointAsync(
            snapshot.InstanceId, snapshot.Health, snapshot.Phase,
            snapshot.Version, snapshot.ServerTick, ct);

        if (ok)
            ticks[snapshot.InstanceId] = snapshot.ServerTick;

        return ok;
    }

    public async Task<bool> DefeatAsync(
        BossLifecycleSnapshot snapshot, CancellationToken ct)
        => await repository.TryDefeatAsync(
            snapshot.InstanceId, snapshot.Version, snapshot.ServerTick, ct);
}
