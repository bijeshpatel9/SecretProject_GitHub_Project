namespace SecretProjectServer.Phase24;

public sealed record BossLifecycleSnapshot(
    string InstanceId,
    string WorldId,
    string ShardId,
    string ZoneId,
    string BossId,
    float Health,
    float MaxHealth,
    int Phase,
    bool Active,
    bool Defeated,
    long Version,
    long ServerTick);

public sealed record BossLifecycleMessage(
    string Type,
    BossLifecycleSnapshot Snapshot);
