namespace SecretProjectServer.Phase24;

public interface IPhase24BossLifecycleRepository
{
    Task<BossLifecycleSnapshot?> GetAsync(string instanceId, CancellationToken ct);
    Task<IReadOnlyList<BossLifecycleSnapshot>> GetActiveAsync(
        string worldId, string shardId, CancellationToken ct);

    Task<bool> TryCreateAsync(BossLifecycleSnapshot snapshot, CancellationToken ct);

    Task<bool> TryCheckpointAsync(
        string instanceId,
        float health,
        int phase,
        long expectedVersion,
        long serverTick,
        CancellationToken ct);

    Task<bool> TryDefeatAsync(
        string instanceId,
        long expectedVersion,
        long serverTick,
        CancellationToken ct);
}
