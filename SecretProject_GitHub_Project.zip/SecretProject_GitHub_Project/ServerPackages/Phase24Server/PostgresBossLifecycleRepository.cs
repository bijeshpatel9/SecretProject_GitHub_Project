using Npgsql;

namespace SecretProjectServer.Phase24;

public sealed class PostgresBossLifecycleRepository : IPhase24BossLifecycleRepository
{
    private readonly string connectionString;

    public PostgresBossLifecycleRepository(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public async Task<BossLifecycleSnapshot?> GetAsync(string instanceId, CancellationToken ct)
    {
        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);

        const string sql = """
        SELECT instance_id, world_id, shard_id, zone_id, boss_id,
               health, max_health, phase, active, defeated, version
        FROM world_boss_instances
        WHERE instance_id=@id
        """;

        await using var cmd = new NpgsqlCommand(sql, db);
        cmd.Parameters.AddWithValue("id", instanceId);
        await using var r = await cmd.ExecuteReaderAsync(ct);

        if (!await r.ReadAsync(ct)) return null;

        return new BossLifecycleSnapshot(
            r.GetString(0), r.GetString(1), r.GetString(2), r.GetString(3),
            r.GetString(4), r.GetFloat(5), r.GetFloat(6), r.GetInt32(7),
            r.GetBoolean(8), r.GetBoolean(9), r.GetInt64(10), 0);
    }

    public async Task<IReadOnlyList<BossLifecycleSnapshot>> GetActiveAsync(
        string worldId, string shardId, CancellationToken ct)
    {
        var result = new List<BossLifecycleSnapshot>();

        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);

        const string sql = """
        SELECT instance_id, world_id, shard_id, zone_id, boss_id,
               health, max_health, phase, active, defeated, version
        FROM world_boss_instances
        WHERE world_id=@world AND shard_id=@shard
          AND active=TRUE AND defeated=FALSE
        """;

        await using var cmd = new NpgsqlCommand(sql, db);
        cmd.Parameters.AddWithValue("world", worldId);
        cmd.Parameters.AddWithValue("shard", shardId);
        await using var r = await cmd.ExecuteReaderAsync(ct);

        while (await r.ReadAsync(ct))
        {
            result.Add(new BossLifecycleSnapshot(
                r.GetString(0), r.GetString(1), r.GetString(2), r.GetString(3),
                r.GetString(4), r.GetFloat(5), r.GetFloat(6), r.GetInt32(7),
                r.GetBoolean(8), r.GetBoolean(9), r.GetInt64(10), 0));
        }

        return result;
    }

    public async Task<bool> TryCreateAsync(
        BossLifecycleSnapshot s, CancellationToken ct)
    {
        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);

        const string sql = """
        INSERT INTO world_boss_instances
        (instance_id, world_id, shard_id, zone_id, boss_id,
         health, max_health, phase, active, defeated, spawn_tick, version, updated_at)
        VALUES (@id,@world,@shard,@zone,@boss,@hp,@maxhp,@phase,TRUE,FALSE,@tick,1,NOW())
        ON CONFLICT (world_id,boss_id) DO NOTHING
        """;

        await using var cmd = new NpgsqlCommand(sql, db);
        cmd.Parameters.AddWithValue("id", s.InstanceId);
        cmd.Parameters.AddWithValue("world", s.WorldId);
        cmd.Parameters.AddWithValue("shard", s.ShardId);
        cmd.Parameters.AddWithValue("zone", s.ZoneId);
        cmd.Parameters.AddWithValue("boss", s.BossId);
        cmd.Parameters.AddWithValue("hp", s.Health);
        cmd.Parameters.AddWithValue("maxhp", s.MaxHealth);
        cmd.Parameters.AddWithValue("phase", s.Phase);
        cmd.Parameters.AddWithValue("tick", s.ServerTick);

        return await cmd.ExecuteNonQueryAsync(ct) == 1;
    }

    public async Task<bool> TryCheckpointAsync(
        string instanceId, float health, int phase, long expectedVersion,
        long serverTick, CancellationToken ct)
    {
        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);

        const string sql = """
        UPDATE world_boss_instances
        SET health=@hp, phase=@phase, version=version+1, updated_at=NOW()
        WHERE instance_id=@id AND version=@version
          AND active=TRUE AND defeated=FALSE
        """;

        await using var cmd = new NpgsqlCommand(sql, db);
        cmd.Parameters.AddWithValue("hp", health);
        cmd.Parameters.AddWithValue("phase", phase);
        cmd.Parameters.AddWithValue("id", instanceId);
        cmd.Parameters.AddWithValue("version", expectedVersion);

        return await cmd.ExecuteNonQueryAsync(ct) == 1;
    }

    public async Task<bool> TryDefeatAsync(
        string instanceId, long expectedVersion, long serverTick, CancellationToken ct)
    {
        await using var db = new NpgsqlConnection(connectionString);
        await db.OpenAsync(ct);
        await using var tx = await db.BeginTransactionAsync(
            System.Data.IsolationLevel.Serializable, ct);

        const string sql = """
        UPDATE world_boss_instances
        SET health=0, active=FALSE, defeated=TRUE,
            version=version+1, updated_at=NOW()
        WHERE instance_id=@id AND version=@version
          AND active=TRUE AND defeated=FALSE
        """;

        await using var cmd = new NpgsqlCommand(sql, db, tx);
        cmd.Parameters.AddWithValue("id", instanceId);
        cmd.Parameters.AddWithValue("version", expectedVersion);

        if (await cmd.ExecuteNonQueryAsync(ct) != 1)
        {
            await tx.RollbackAsync(ct);
            return false;
        }

        await tx.CommitAsync(ct);
        return true;
    }
}
