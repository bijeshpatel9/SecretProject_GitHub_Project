using System.Net.WebSockets;
using System.Text;
using System.Text.Json;

namespace SecretProjectServer.Phase24;

public sealed class Phase24WebSocketBossBroadcaster
{
    private readonly object gate = new();
    private readonly HashSet<WebSocket> clients = new();

    public void Add(WebSocket socket)
    {
        lock (gate) clients.Add(socket);
    }

    public void Remove(WebSocket socket)
    {
        lock (gate) clients.Remove(socket);
    }

    public async Task BroadcastAsync(
        BossLifecycleSnapshot snapshot, CancellationToken ct)
    {
        var payload = JsonSerializer.SerializeToUtf8Bytes(
            new BossLifecycleMessage("boss_state", snapshot));

        WebSocket[] targets;
        lock (gate) targets = clients.ToArray();

        foreach (var socket in targets)
        {
            if (socket.State != WebSocketState.Open)
            {
                Remove(socket);
                continue;
            }

            try
            {
                await socket.SendAsync(
                    payload, WebSocketMessageType.Text, true, ct);
            }
            catch
            {
                Remove(socket);
            }
        }
    }
}
