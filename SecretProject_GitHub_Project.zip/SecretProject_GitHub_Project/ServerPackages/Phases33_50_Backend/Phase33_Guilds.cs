using System; using System.Collections.Generic; using SecretProject.Shared;
namespace SecretProject.Phase33 {
 public enum GuildRole { Member,Officer,Leader }
 public sealed record GuildMember(string PlayerId,GuildRole Role,long JoinedAt);
 public sealed record Guild(string Id,string Name,string LeaderId,long Version,List<GuildMember> Members,long BankGold,string TerritoryId);
 public sealed record GuildBankTx(string Id,string GuildId,string PlayerId,long Delta,string Reason,long Time);
 public sealed class GuildService {
  readonly Dictionary<string,Guild> g=new(); readonly Dictionary<string,GuildBankTx> tx=new(); readonly IIdempotencyStore idem;
  public GuildService(IIdempotencyStore idem){this.idem=idem;}
  public Result<Guild> Create(string id,string name,string leader){ if(g.ContainsKey(id))return Result<Guild>.Fail("guild_exists"); var x=new Guild(id,name,leader,1,new(){new(leader,GuildRole.Leader,DateTimeOffset.UtcNow.ToUnixTimeSeconds())},0,null);g[id]=x;return Result<Guild>.Ok(x,1); }
  public Result<Guild> Deposit(string id,string player,long amount,string request){Guard.Positive(amount,"amount");if(idem.Seen(request))return Result<Guild>.Fail("duplicate");if(!g.TryGetValue(id,out var x))return Result<Guild>.Fail("not_found");if(!x.Members.Exists(m=>m.PlayerId==player))return Result<Guild>.Fail("not_member");var n=x with {BankGold=x.BankGold+amount,Version=x.Version+1};g[id]=n;idem.Mark(request);return Result<Guild>.Ok(n,n.Version);}
  public Result<Guild> Withdraw(string id,string player,long amount,string request){Guard.Positive(amount,"amount");if(idem.Seen(request))return Result<Guild>.Fail("duplicate");if(!g.TryGetValue(id,out var x))return Result<Guild>.Fail("not_found");var m=x.Members.Find(m=>m.PlayerId==player);if(m is null || m.Role==GuildRole.Member)return Result<Guild>.Fail("permission");if(x.BankGold<amount)return Result<Guild>.Fail("insufficient");var n=x with {BankGold=x.BankGold-amount,Version=x.Version+1};g[id]=n;idem.Mark(request);return Result<Guild>.Ok(n,n.Version);}
  public Result<Guild> SetTerritory(string id,string territory){if(!g.TryGetValue(id,out var x))return Result<Guild>.Fail("not_found");var n=x with{TerritoryId=territory,Version=x.Version+1};g[id]=n;return Result<Guild>.Ok(n,n.Version);}
 }
}
