using System;using System.Collections.Generic;using System.Linq;
namespace SecretProject.Phase35 {
 public enum RunState{Forming,Running,Completed,Failed}
 public sealed record Party(string Id,string Leader,List<string> Members,int MaxSize);
 public sealed record DungeonRun(string Id,string PartyId,string DungeonId,int Difficulty,RunState State,long Seed,int Checkpoint);
 public sealed class PartyService { readonly Dictionary<string,Party>p=new(); readonly Dictionary<string,DungeonRun>r=new(); public Party Create(string id,string leader,int max=5)=>p[id]=new(id,leader,new(){leader},max); public bool Join(string id,string player){var x=p[id];if(x.Members.Contains(player)||x.Members.Count>=x.MaxSize)return false;x.Members.Add(player);return true;} public DungeonRun Start(string id,string dungeon,int difficulty,long seed){var x=new DungeonRun(id,p.Values.First(z=>z.Members.Contains(id)).Id,dungeon,difficulty,RunState.Running,seed,0);r[id]=x;return x;} public DungeonRun Checkpoint(string id,int cp)=>r[id]=r[id] with{Checkpoint=Math.Max(r[id].Checkpoint,cp)}; }
}
