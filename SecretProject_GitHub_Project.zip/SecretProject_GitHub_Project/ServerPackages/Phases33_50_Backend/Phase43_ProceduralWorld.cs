using System;using System.Collections.Generic;
namespace SecretProject.Phase43 { public sealed record Tile(int X,int Y,int Biome,int Level,long Seed); public sealed class WorldGenerator {public Tile Generate(long worldSeed,int region,int x,int y){unchecked{long s=worldSeed*31L+region*73856093L+x*19349663L+y*83492791L;var rng=new Random((int)s);return new(x,y,rng.Next(0,8),Math.Max(1,region/2+rng.Next(0,10)),s);}}public IEnumerable<Tile> Region(long seed,int region,int radius){for(int y=-radius;y<=radius;y++)for(int x=-radius;x<=radius;x++)yield return Generate(seed,region,x,y);}}
}
