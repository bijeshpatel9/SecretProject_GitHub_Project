using System; using System.Collections.Generic;
namespace SecretProject.Phase34 {
 public enum WarState { Scheduled,Active,Finished,Cancelled }
 public sealed record GuildWar(string Id,string Attacker,string Defender,string Territory,DateTimeOffset Start,DateTimeOffset End,WarState State,long AttackerScore,long DefenderScore);
 public sealed class GuildWarService { readonly Dictionary<string,GuildWar>w=new(); public GuildWar Schedule(string id,string a,string d,string t,DateTimeOffset start,TimeSpan duration)=>w[id]=new(id,a,d,t,start,start+duration,WarState.Scheduled,0,0); public GuildWar Tick(string id,DateTimeOffset now){var x=w[id];var s=now<x.Start?WarState.Scheduled:now>=x.End?WarState.Finished:WarState.Active;var n=x with{State=s};return w[id]=n;} public GuildWar Score(string id,bool attacker,long points){var x=w[id];return w[id]=attacker?x with{AttackerScore=x.AttackerScore+points}:x with{DefenderScore=x.DefenderScore+points};} }
}
