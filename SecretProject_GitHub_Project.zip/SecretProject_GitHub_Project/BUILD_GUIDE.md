# Build guide

## GitHub upload
1. Extract this ZIP.
2. Upload the **contents** of the extracted folder to a GitHub repository.
3. Commit to `main`.
4. Open **Actions** and run **Build Android APK**.

## GitHub secrets
The workflow expects the Unity credentials/license method supported by the GameCI Unity version you use. Add the required Unity secrets in GitHub repository settings. For signed APKs, add the Android keystore secrets as well. If no keystore is supplied, adapt the workflow to use Unity's debug signing for a development APK.

## Important
This repository is a build-ready project scaffold assembled from the available Phase 01–50 source. It has the Unity project structure, Android build target, build script, scene, and CI workflow. Unity itself must perform the final C# compilation/import and Android packaging on the cloud runner.

The MMO server stack is separate and belongs under `ServerPackages/`; PostgreSQL/Redis must run on a server/cloud host, not inside the APK.
